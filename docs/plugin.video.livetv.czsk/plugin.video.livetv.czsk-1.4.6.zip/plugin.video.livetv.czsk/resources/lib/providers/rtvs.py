# -*- coding: utf-8 -*-
# Based on cache-sk's freeview.sk rtvs provider
# License: AGPL v.3

import requests

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

CHANNELS = {
    'jednotka': 1,
    'dvojka': 2,
    '24': 3,
    'stv24': 3,
    'rtvs24': 3,
    'online': 4,
    'nrsr': 5,
    'rtvs': 6,
    'sport': 15,
    'rtvssport': 15
}

# Alternative streams (backup)
ALTERNATIVE = {
    'jednotka': 'https://ocko-live.ssl.cdn.cra.cz/channels/stv1/playlist/cze/live_hd.m3u8',
    'dvojka': 'https://ocko-live.ssl.cdn.cra.cz/channels/stv2/playlist/cze/live_hd.m3u8'
}

API_INIT = "https://www.rtvs.sk/televizia/tv"
API = "https://www.rtvs.sk/json/live5f.json"
PARAMS = {'ad': 1, 'b': 'chrome', 'p': 'win', 'v': '77', 'f': 0, 'd': 1}
CHANNEL_PARAM = 'c'
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'
}


def get_live_stream(channel_id, use_alternative=False):
    """Get live stream URL for RTVS channels"""
    if channel_id not in CHANNELS:
        return None
    
    # Try alternative first if requested
    if use_alternative and channel_id in ALTERNATIVE:
        return {
            'url': ALTERNATIVE[channel_id],
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        # Initialize session
        session.get(API_INIT, timeout=10)
        
        # Get stream
        params = {CHANNEL_PARAM: CHANNELS[channel_id]}
        params.update(PARAMS)
        response = session.get(API, params=params, timeout=15)
        data = response.json()
        
        if 'clip' in data and 'sources' in data['clip']:
            clip = data['clip']
            sources = clip['sources']
            hls = None
            mpd = None
            
            for src in sources:
                if src['type'] == "application/dash+xml":
                    mpd = src['src'].replace('\n', '')
                elif src['type'] == "application/x-mpegurl":
                    hls = src['src'].replace('\n', '')
            
            # Prefer HLS
            if hls:
                return {
                    'url': hls,
                    'manifest_type': 'hls',
                    'headers': HEADERS
                }
            elif mpd:
                return {
                    'url': mpd,
                    'manifest_type': 'mpd',
                    'headers': HEADERS
                }
        
        # Fallback to alternative
        if channel_id in ALTERNATIVE:
            return {
                'url': ALTERNATIVE[channel_id],
                'manifest_type': 'hls',
                'headers': HEADERS
            }
            
    except Exception as e:
        # Try alternative on error
        if channel_id in ALTERNATIVE:
            return {
                'url': ALTERNATIVE[channel_id],
                'manifest_type': 'hls',
                'headers': HEADERS
            }
        return {'error': str(e)}
    
    return None
