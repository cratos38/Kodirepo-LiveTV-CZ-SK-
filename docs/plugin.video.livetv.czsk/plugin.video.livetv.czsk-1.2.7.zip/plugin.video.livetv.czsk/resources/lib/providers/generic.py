# -*- coding: utf-8 -*-
"""
Provider: Generic
For channels with direct stream URLs (music channels, etc.)
"""

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': '*/*'
}


def get_live_stream(channel_id, stream_url):
    """
    Get live stream for generic channel
    These channels have direct, publicly available streams
    
    Args:
        channel_id: Channel identifier
        stream_url: Direct stream URL from channel config
        
    Returns:
        dict with 'url' and 'manifest_type' or None
    """
    if not stream_url:
        return None
    
    return {
        'url': stream_url,
        'manifest_type': 'hls',
        'headers': HEADERS
    }


def get_catchup_stream(channel_id, utc_timestamp):
    """
    Generic channels (music, etc.) don't support catchup
    """
    return {'error': 'Catchup not available for this channel'}
