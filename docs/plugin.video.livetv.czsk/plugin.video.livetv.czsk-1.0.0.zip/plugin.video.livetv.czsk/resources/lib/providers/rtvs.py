# -*- coding: utf-8 -*-
"""
Provider: RTVS (Slovak public television)
LIVE TV + Archive (own productions only)
"""
import re
import json
from datetime import datetime

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Referer': 'https://www.rtvs.sk/'
}

# RTVS Live stream URLs - these are publicly available
LIVE_STREAMS = {
    'jednotka': {
        'primary': 'https://n5.stv.livebox.sk/stv-tv/addfd31846e34200883cc2b4e9e6c855/stv1.smil/playlist.m3u8',
        'backup': 'https://sktv.plainrock127.xyz/get.php?x=STV1'
    },
    'dvojka': {
        'primary': 'https://n5.stv.livebox.sk/stv-tv/addfd31846e34200883cc2b4e9e6c855/stv2.smil/playlist.m3u8',
        'backup': 'http://88.212.15.27/live/test_dvojka_25p/playlist.m3u8'
    },
    'rtvs24': {
        'primary': 'http://88.212.15.27/live/test_trojka_25p/playlist.m3u8',
        'backup': None
    },
    'rtvssport': {
        'primary': 'http://88.212.15.27/live/test_rtvs_sport_hevc/playlist.m3u8',
        'backup': None
    }
}

# Archive API
ARCHIVE_API = 'https://www.rtvs.sk/json/archive.json'
ARCHIVE_STREAM_API = 'https://www.rtvs.sk/json/archive_stream.json'


def get_live_stream(channel_id):
    """
    Get live stream URL for RTVS channel
    
    Args:
        channel_id: Channel identifier (jednotka, dvojka, rtvs24, rtvssport)
        
    Returns:
        dict with 'url' and 'manifest_type' or None
    """
    import requests
    
    channel_data = LIVE_STREAMS.get(channel_id)
    if not channel_data:
        return None
    
    # Try primary stream first
    primary_url = channel_data.get('primary')
    if primary_url:
        try:
            session = requests.Session()
            session.headers.update(HEADERS)
            response = session.head(primary_url, timeout=5, allow_redirects=True)
            if response.status_code == 200:
                return {
                    'url': primary_url,
                    'manifest_type': 'hls',
                    'headers': HEADERS
                }
        except:
            pass
    
    # Try backup stream
    backup_url = channel_data.get('backup')
    if backup_url:
        return {
            'url': backup_url,
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    
    return None


def get_archive_programs(channel_id='jednotka', page=1, limit=20):
    """
    Get list of available archive programs
    Note: Only RTVS own productions are available, not licensed content
    
    Args:
        channel_id: Channel identifier
        page: Page number
        limit: Items per page
        
    Returns:
        list of available programs
    """
    import requests
    
    # Map our channel IDs to RTVS archive channel IDs
    archive_channel_map = {
        'jednotka': 'stv1',
        'dvojka': 'stv2',
        'rtvs24': 'stv3',
        'rtvssport': 'sport'
    }
    
    archive_channel = archive_channel_map.get(channel_id, 'stv1')
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        params = {
            'channel': archive_channel,
            'page': page,
            'limit': limit
        }
        
        response = session.get(ARCHIVE_API, params=params, timeout=15)
        response.raise_for_status()
        
        data = response.json()
        return data.get('items', [])
        
    except Exception as e:
        print(f"[RTVS Provider] Error getting archive: {e}")
        return []


def get_archive_stream(program_id):
    """
    Get stream URL for archived program
    
    Args:
        program_id: ID of the archived program
        
    Returns:
        dict with 'url' or error message
    """
    import requests
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        params = {'id': program_id}
        response = session.get(ARCHIVE_STREAM_API, params=params, timeout=15)
        response.raise_for_status()
        
        data = response.json()
        
        if 'clip' in data and 'sources' in data['clip']:
            sources = data['clip']['sources']
            # Prefer HLS
            for source in sources:
                if source.get('type') == 'application/x-mpegurl' or '.m3u8' in source.get('src', ''):
                    return {
                        'url': source['src'],
                        'manifest_type': 'hls',
                        'title': data['clip'].get('title', ''),
                        'plot': data['clip'].get('description', '')
                    }
            # Fallback to first source
            if sources:
                return {
                    'url': sources[0].get('src'),
                    'manifest_type': 'hls',
                    'title': data['clip'].get('title', '')
                }
        
        return {'error': 'Stream not available in archive'}
        
    except Exception as e:
        return {'error': f'Archive error: {str(e)}'}


def get_catchup_stream(channel_id, utc_timestamp):
    """
    Try to get catchup stream for RTVS
    Note: Only works for RTVS own productions
    
    This searches the archive for a program that matches the timestamp
    """
    import requests
    
    try:
        target_dt = datetime.fromtimestamp(int(utc_timestamp))
        
        # Get archive programs for that date
        programs = get_archive_programs(channel_id, page=1, limit=50)
        
        # Try to find matching program
        for prog in programs:
            if 'broadcast_time' in prog:
                try:
                    prog_time = datetime.strptime(prog['broadcast_time'], '%Y-%m-%d %H:%M:%S')
                    diff = abs((prog_time - target_dt).total_seconds())
                    if diff < 1800:  # Within 30 minutes
                        return get_archive_stream(prog['id'])
                except:
                    continue
        
        return {'error': 'Program not available in archive (may be licensed content)'}
        
    except Exception as e:
        return {'error': f'Catchup error: {str(e)}'}
