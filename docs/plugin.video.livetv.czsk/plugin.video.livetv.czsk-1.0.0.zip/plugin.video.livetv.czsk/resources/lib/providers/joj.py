# -*- coding: utf-8 -*-
"""
Provider: JOJ (Slovak commercial TV)
LIVE TV only - Uses fallback URLs
Note: JOJ is heavily protected, direct streams don't work
"""

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Referer': 'https://live.joj.sk/'
}

# JOJ Fallback streams
# These are CDN URLs that may work temporarily
# Based on freeview.sk fallback approach
FALLBACK_BASE = "https://live.cdn.joj.sk/live/{stream}?loc=SK&exp=1716281798&hash=9d0862c9645f8f9ffd8736a3e732735333d1b1b665c1a9bf3db84bc8b10c0038"

CHANNEL_STREAMS = {
    'joj': {
        'name': 'JOJ',
        'stream': 'joj.m3u8',
        'web_url': 'https://live.joj.sk'
    },
    'jojplus': {
        'name': 'JOJ Plus',
        'stream': 'plus.m3u8',
        'web_url': 'https://plus.joj.sk/live'
    },
    'wau': {
        'name': 'WAU',
        'stream': 'wau.m3u8',
        'web_url': 'https://wau.joj.sk/live'
    },
    'jojfamily': {
        'name': 'JOJ Family',
        'stream': 'family.m3u8',
        'web_url': 'https://jojfamily.blesk.cz/live'
    },
    'joj24': {
        'name': 'JOJ 24',
        'stream': 'joj_news.m3u8',
        'web_url': 'https://joj24.noviny.sk/'
    },
    'jojcinema': {
        'name': 'JOJ Cinema',
        'stream': 'cinema.m3u8',
        'web_url': 'https://live.joj.sk'
    },
    'jojsport': {
        'name': 'JOJ Sport',
        'stream': 'joj_sport.m3u8',
        'web_url': 'https://live.joj.sk'
    },
    'csfilm': {
        'name': 'CS Film',
        'stream': 'cs_film.m3u8',
        'web_url': 'https://live.joj.sk'
    },
    'cshistory': {
        'name': 'CS History',
        'stream': 'cs_history.m3u8',
        'web_url': 'https://live.joj.sk'
    },
    'csmystery': {
        'name': 'CS Mystery',
        'stream': 'cs_mystery.m3u8',
        'web_url': 'https://live.joj.sk'
    }
}


def get_live_stream(channel_id):
    """
    Get live stream URL for JOJ channel
    
    JOJ uses geo-protection and token-based authentication
    Direct streams rarely work, using fallback approach
    
    Args:
        channel_id: Channel identifier
        
    Returns:
        dict with 'url' and 'manifest_type' or None
    """
    import requests
    
    channel_data = CHANNEL_STREAMS.get(channel_id)
    if not channel_data:
        return None
    
    # Use fallback URL
    stream_url = FALLBACK_BASE.format(stream=channel_data['stream'])
    
    # Try to verify stream works
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        # Warm up the CDN
        session.get(stream_url, timeout=5)
        session.get(stream_url, timeout=5)
        
        return {
            'url': stream_url,
            'manifest_type': 'hls',
            'headers': {
                'User-Agent': HEADERS['User-Agent'],
                'Referer': stream_url,
                'Origin': stream_url
            }
        }
    except Exception as e:
        print(f"[JOJ Provider] Fallback failed: {e}")
    
    # If fallback fails, try alternative approach
    return _try_alternative_stream(channel_id, channel_data)


def _try_alternative_stream(channel_id, channel_data):
    """
    Try alternative methods to get JOJ stream
    This attempts to scrape from web page
    """
    import requests
    import re
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        response = session.get(channel_data['web_url'], timeout=15)
        html = response.text
        
        # Look for iframe with media.joj.sk
        iframe_pattern = r'<iframe[^>]+src=["\']([^"\']*media\.joj\.sk[^"\']*)["\']'
        match = re.search(iframe_pattern, html, re.IGNORECASE)
        
        if match:
            iframe_url = match.group(1)
            
            # Get iframe content
            response = session.get(iframe_url, timeout=15)
            iframe_html = response.text
            
            # Extract HLS URL
            hls_pattern = r'"hls":\s*"([^"]+)"'
            hls_match = re.search(hls_pattern, iframe_html)
            
            if hls_match:
                hls_url = hls_match.group(1)
                # Replace channel in URL if needed
                if 'replace' in channel_data:
                    hls_url = hls_url.replace('joj.m3u8', channel_data['stream'])
                
                return {
                    'url': hls_url,
                    'manifest_type': 'hls',
                    'headers': {
                        'User-Agent': HEADERS['User-Agent'],
                        'Referer': 'https://media.joj.sk/',
                        'Origin': 'https://media.joj.sk'
                    }
                }
    except Exception as e:
        print(f"[JOJ Provider] Alternative method failed: {e}")
    
    return None


def get_catchup_stream(channel_id, utc_timestamp):
    """
    JOJ does not support catchup for free users
    """
    return {'error': 'JOJ catchup is not available'}
