# -*- coding: utf-8 -*-
"""
Provider: TA3 (Slovak news channel)
LIVE TV only - 24/7 news, no catchup needed
"""

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': '*/*',
    'Referer': 'https://www.ta3.com/'
}

# TA3 streams
STREAMS = {
    'ta3': {
        'primary': 'https://sktv.plainrock127.xyz/get.php?x=TA3',
        'backup': 'https://ta3-live-hls.ssl.cdn.cra.cz/ta3-live/ta3.stream.1.smil/playlist.m3u8',
        'web': 'https://www.ta3.com/live'
    }
}


def get_live_stream(channel_id='ta3'):
    """
    Get live stream URL for TA3
    
    Args:
        channel_id: Channel identifier (always 'ta3')
        
    Returns:
        dict with 'url' and 'manifest_type' or None
    """
    import requests
    
    streams = STREAMS.get(channel_id)
    if not streams:
        return None
    
    session = requests.Session()
    session.headers.update(HEADERS)
    
    # Try primary stream
    try:
        response = session.head(streams['primary'], timeout=5, allow_redirects=True)
        if response.status_code == 200:
            return {
                'url': streams['primary'],
                'manifest_type': 'hls',
                'headers': HEADERS
            }
    except:
        pass
    
    # Try backup
    try:
        return {
            'url': streams['backup'],
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    except:
        pass
    
    return None


def get_catchup_stream(channel_id, utc_timestamp):
    """
    TA3 is 24/7 news - catchup doesn't make sense
    """
    return {'error': 'TA3 is live news channel, no catchup available'}
