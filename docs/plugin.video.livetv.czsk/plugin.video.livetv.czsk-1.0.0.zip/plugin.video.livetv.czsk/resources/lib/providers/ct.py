# -*- coding: utf-8 -*-
"""
Provider: CT (Ceska televize)
LIVE TV + CATCHUP support
Based on cratos38's ct_NUEVO_API_2026.py
"""
import json
import time
from datetime import datetime, timedelta

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

# API URLs
API_LIVE = 'https://api.ceskatelevize.cz/video/v1/playlist-live/v1/stream-data/channel/'
API_GRAPHQL = 'https://api.ceskatelevize.cz/graphql/'
API_CATCHUP = 'https://api.ceskatelevize.cz/video/v1/playlist-vod/v1/stream-data/media/external/'

# Parameters
PARAMS_LIVE = {
    'canPlayDrm': 'false',
    'streamType': 'hls',
    'quality': 'web',
    'maxQualityCount': '5'
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json',
    'Content-Type': 'application/json'
}

# Channel mapping to CT API channel IDs
CHANNEL_MAP = {
    'ct1': 'CH_1',
    'ct2': 'CH_2', 
    'ct24': 'CH_24',
    'ctsport': 'CH_4',
    'ctd': 'CH_5',
    'ctart': 'CH_6',
    'ctdart': 'CH_5'
}

# Channel mapping for catchup GraphQL
CATCHUP_CHANNEL_MAP = {
    'ct1': 'ct1',
    'ct2': 'ct2',
    'ct24': 'ct24',
    'ctsport': 'ct4',
    'ctdart': 'ctD'
}

# GraphQL query for program schedule
GRAPHQL_QUERY = '''query TvProgramDailyTablet($channels: [String!]!, $date: Date!) {
  TVProgramDailyChannelsPlanV2(channels: $channels, date: $date) {
    channel
    program {
      idec
      title
      description
      start
      end
      isPlayableNow
    }
  }
}'''


def get_live_stream(channel_id):
    """
    Get live stream URL for CT channel
    
    Args:
        channel_id: Channel identifier (ct1, ct2, ct24, ctsport, ctdart)
        
    Returns:
        dict with 'url' and 'manifest_type' or None on error
    """
    import requests
    
    api_channel = CHANNEL_MAP.get(channel_id)
    if not api_channel:
        return None
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        url = API_LIVE + api_channel
        response = session.get(url, params=PARAMS_LIVE, timeout=15)
        response.raise_for_status()
        
        data = response.json()
        stream_url = data.get('streamUrls', {}).get('main')
        
        if stream_url:
            return {
                'url': stream_url,
                'manifest_type': 'hls',
                'headers': HEADERS
            }
    except Exception as e:
        print(f"[CT Provider] Error getting live stream: {e}")
    
    return None


def get_catchup_stream(channel_id, utc_timestamp):
    """
    Get catchup/archive stream URL for CT channel
    
    Args:
        channel_id: Channel identifier
        utc_timestamp: Unix timestamp of program start
        
    Returns:
        dict with 'url', 'title', 'plot' or None on error
    """
    import requests
    
    gql_channel = CATCHUP_CHANNEL_MAP.get(channel_id)
    if not gql_channel:
        return {'error': 'Channel does not support catchup'}
    
    try:
        # Convert timestamp to datetime
        target_dt = datetime.fromtimestamp(int(utc_timestamp))
        date_str = target_dt.strftime('%m.%d.%Y')
        
        session = requests.Session()
        session.headers.update(HEADERS)
        
        # Query GraphQL for program list
        post_data = {
            'operationName': 'TvProgramDailyTablet',
            'variables': {
                'channels': gql_channel,
                'date': date_str
            },
            'query': GRAPHQL_QUERY
        }
        
        response = session.post(API_GRAPHQL, json=post_data, timeout=15)
        response.raise_for_status()
        data = response.json()
        
        # Find the program matching the timestamp
        programmes = data.get('data', {}).get('TVProgramDailyChannelsPlanV2', [])
        if not programmes:
            return {'error': 'No programs found for this date'}
        
        program_list = programmes[0].get('program', [])
        selected = None
        
        for prog in program_list:
            if 'start' in prog and 'idec' in prog and prog['idec']:
                try:
                    prog_start = datetime.strptime(prog['start'][:19], '%Y-%m-%dT%H:%M:%S')
                    diff = abs((prog_start - target_dt).total_seconds())
                    if diff < 1800:  # Within 30 minutes
                        selected = prog
                        break
                except:
                    continue
        
        if not selected:
            return {'error': 'Program not found in schedule'}
        
        # Get stream URL using idec
        idec = selected['idec']
        stream_url = f"{API_CATCHUP}{idec}?canPlayDrm=false&quality=web&streamType=hls&origin=ivysilani&usePlayability=true"
        
        response = session.get(stream_url, timeout=15)
        response.raise_for_status()
        stream_data = response.json()
        
        streams = stream_data.get('streams', [])
        if not streams or 'url' not in streams[0]:
            return {'error': 'Stream URL not available'}
        
        return {
            'url': streams[0]['url'],
            'manifest_type': 'hls',
            'title': selected.get('title', 'Catchup'),
            'plot': selected.get('description', ''),
            'headers': HEADERS
        }
        
    except Exception as e:
        return {'error': f'Catchup error: {str(e)}'}


def get_epg(channel_id, date=None):
    """
    Get EPG data for CT channel
    
    Args:
        channel_id: Channel identifier
        date: Date string (MM.DD.YYYY) or None for today
        
    Returns:
        list of programs or empty list
    """
    import requests
    
    gql_channel = CATCHUP_CHANNEL_MAP.get(channel_id)
    if not gql_channel:
        return []
    
    if date is None:
        date = datetime.now().strftime('%m.%d.%Y')
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        post_data = {
            'operationName': 'TvProgramDailyTablet',
            'variables': {
                'channels': gql_channel,
                'date': date
            },
            'query': GRAPHQL_QUERY
        }
        
        response = session.post(API_GRAPHQL, json=post_data, timeout=15)
        response.raise_for_status()
        data = response.json()
        
        programmes = data.get('data', {}).get('TVProgramDailyChannelsPlanV2', [])
        if programmes:
            return programmes[0].get('program', [])
            
    except Exception as e:
        print(f"[CT Provider] Error getting EPG: {e}")
    
    return []
