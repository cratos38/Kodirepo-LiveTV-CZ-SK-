# -*- coding: utf-8 -*-
"""
Proveedor ČT con LIVE TV + CATCHUP (API 2025/2026)
Based on cache-sk's freeview.sk ct provider
License: AGPL v.3
"""

import requests
import json
from datetime import datetime, timedelta
import time

# LIVE TV API
API = 'https://api.ceskatelevize.cz/video/v1/playlist-live/v1/stream-data/channel/'
PARAMS = {'canPlayDrm': 'false', 'streamType': 'hls', 'quality': 'web', 'maxQualityCount': '5'}

CHANNELS = {
    'ct1': 'CH_1',
    'ct2': 'CH_2',
    'ct24': 'CH_24',
    'ctsport': 'CH_4',
    'ctd': 'CH_5',
    'ctart': 'CH_6',
    'ctdart': [
        {'channel': 'ctd', 'from': 8, 'to': 20},
        {'channel': 'ctart', 'from': 0, 'to': 8},
        {'channel': 'ctart', 'from': 20, 'to': 24}
    ]
}

# CT Sport Plus API
SPAPI = 'https://api.ceskatelevize.cz/graphql/'
SPPARAMS = {
    'client': 'website', 
    'version': '1.64.1', 
    'operationName': 'LiveBroadcastFind', 
    'variables': '{}', 
    'extensions': '{"persistedQuery":{"version":1,"sha256Hash":"cd7619a5186ef6277c1e82179c669e02e3edac97739593bc28fa32df5041d644"}}'
}
SPNONE = 'CH_7'
SPCHANNEL = 'ctSportExtra'
SPPREFIX = 'CH_'

# CATCHUP API
GRAPHQL_URL = 'https://api.ceskatelevize.cz/graphql/'
CATCHUP_STREAM_URL = 'https://api.ceskatelevize.cz/video/v1/playlist-vod/v1/stream-data/media/external/'
CATCHUP_CHANNEL_MAP = {
    'ct1': 'ct1',
    'ct2': 'ct2', 
    'ct24': 'ct24',
    'ctsport': 'ct4',
    'ctdart': 'ctD',
    'ctd': 'ctD',
    'ctart': 'ctD'
}

GRAPHQL_QUERY = '''query TvProgramDailyTablet($channels: [String!]!, $date: Date!) {
  TVProgramDailyChannelsPlanV2(channels: $channels, date: $date) {
    channel
    program {
      idec
      title
      description
      start
      end
      isPlayableNow
    }
  }
}'''

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
}


def get_sport_plus_channel(session):
    """Get current CT Sport Plus channel"""
    try:
        response = session.get(SPAPI, params=SPPARAMS, timeout=10)
        data = response.json()
        available = []
        if 'data' in data and data['data'] and 'liveBroadcastFind' in data['data'] and data['data']['liveBroadcastFind']:
            for live in data['data']['liveBroadcastFind']:
                if 'id' in live and live['id'] and 'current' in live and live['current'] and 'channel' in live['current'] and live['current']['channel'] and live['current']['channel'] == SPCHANNEL:
                    available.append(live['id'])
        if len(available) >= 1:
            return SPPREFIX + available[0]
    except:
        pass
    return SPNONE


def get_live_stream(channel_id):
    """Get live stream URL for CT channels"""
    session = requests.Session()
    session.headers.update(HEADERS)
    
    channel = channel_id
    
    # Handle channel mapping
    if channel in CHANNELS:
        channel_code = CHANNELS[channel]
    elif channel == 'ctsportplus':
        channel_code = get_sport_plus_channel(session)
    else:
        return None
    
    # Handle time-based channels (CT:D/art)
    if isinstance(channel_code, list):
        now = datetime.now().hour
        for chn in channel_code:
            if chn['from'] <= now < chn['to'] and chn['channel'] in CHANNELS:
                channel_code = CHANNELS[chn['channel']]
                break
    
    if isinstance(channel_code, list):
        return {'error': 'Could not determine channel'}
    
    try:
        response = session.get(API + channel_code, params=PARAMS, timeout=15)
        data = response.json()
        
        if 'streamUrls' in data and data['streamUrls'] and 'main' in data['streamUrls'] and data['streamUrls']['main']:
            return {
                'url': data['streamUrls']['main'],
                'manifest_type': 'hls',
                'headers': HEADERS
            }
        else:
            return {'error': 'No stream URL in response'}
    except Exception as e:
        return {'error': str(e)}
    
    return None


def get_catchup_stream(channel_id, utc_timestamp):
    """
    Get catchup stream URL for CT channels
    
    Args:
        channel_id: Channel ID (ct1, ct2, ct24, ctsport, ctdart)
        utc_timestamp: UTC timestamp of the program start
        
    Returns:
        dict with 'url', 'manifest_type', 'title', 'plot' or 'error'
    """
    session = requests.Session()
    session.headers.update({
        'User-Agent': HEADERS['User-Agent'],
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    })
    
    # Check if channel supports catchup
    gql_channel = CATCHUP_CHANNEL_MAP.get(channel_id)
    if not gql_channel:
        return {'error': f'Channel {channel_id} does not support catchup'}
    
    # Convert UTC timestamp to date
    try:
        utc_ts = int(utc_timestamp)
        target_dt = datetime.fromtimestamp(utc_ts)
        date_str = target_dt.strftime('%m.%d.%Y')
    except Exception as e:
        return {'error': f'Invalid timestamp: {e}'}
    
    # Query GraphQL for program list
    post_data = {
        'operationName': 'TvProgramDailyTablet',
        'variables': {
            'channels': gql_channel,
            'date': date_str
        },
        'query': GRAPHQL_QUERY
    }
    
    try:
        response = session.post(GRAPHQL_URL, json=post_data, timeout=15)
        response.raise_for_status()
        data = response.json()
    except Exception as e:
        return {'error': f'GraphQL API error: {e}'}
    
    # Find the program
    programmes = data.get('data', {}).get('TVProgramDailyChannelsPlanV2', [])
    if not programmes:
        return {'error': f'No programs found for {date_str}'}
    
    program_list = programmes[0].get('program', [])
    if not program_list:
        return {'error': f'Empty program list for {date_str}'}
    
    # Find program matching the timestamp (within 30 minutes tolerance)
    selected = None
    for prog in program_list:
        if 'start' in prog and 'idec' in prog and prog['idec']:
            try:
                # Usamos time.strptime por bug de Kodi con datetime.strptime
                prog_start = datetime(*(time.strptime(prog['start'][:19], '%Y-%m-%dT%H:%M:%S')[:6]))
                diff = abs((prog_start - target_dt).total_seconds())
                if diff < 1800:  # 30 minutes tolerance
                    selected = prog
                    break
            except:
                continue
    
    if not selected:
        return {'error': 'Program not found for this timestamp'}
    
    # Get stream URL using idec
    idec = selected['idec']
    stream_url_api = f"{CATCHUP_STREAM_URL}{idec}?canPlayDrm=false&quality=web&streamType=hls&origin=ivysilani&usePlayability=true"
    
    try:
        response = session.get(stream_url_api, timeout=15)
        response.raise_for_status()
        stream_data = response.json()
    except Exception as e:
        return {'error': f'Stream API error: {e}'}
    
    streams = stream_data.get('streams', [])
    if not streams or 'url' not in streams[0]:
        return {'error': 'No stream URL in catchup response'}
    
    return {
        'url': streams[0]['url'],
        'manifest_type': 'hls',
        'headers': HEADERS,
        'title': selected.get('title', 'Catchup'),
        'plot': selected.get('description', '')
    }


def supports_catchup(channel_id):
    """Check if channel supports catchup"""
    return channel_id in CATCHUP_CHANNEL_MAP
