# -*- coding: utf-8 -*-
# Based on cache-sk's freeview.sk ct provider
# License: AGPL v.3

import requests
import datetime

API = 'https://api.ceskatelevize.cz/video/v1/playlist-live/v1/stream-data/channel/'
PARAMS = {'canPlayDrm': 'false', 'streamType': 'hls', 'quality': 'web', 'maxQualityCount': '5'}

CHANNELS = {
    'ct1': 'CH_1',
    'ct2': 'CH_2',
    'ct24': 'CH_24',
    'ctsport': 'CH_4',
    'ctd': 'CH_5',
    'ctart': 'CH_6',
    'ctdart': [
        {'channel': 'ctd', 'from': 8, 'to': 20},
        {'channel': 'ctart', 'from': 0, 'to': 8},
        {'channel': 'ctart', 'from': 20, 'to': 24}
    ]
}

# CT Sport Plus API
SPAPI = 'https://api.ceskatelevize.cz/graphql/'
SPPARAMS = {
    'client': 'website', 
    'version': '1.64.1', 
    'operationName': 'LiveBroadcastFind', 
    'variables': '{}', 
    'extensions': '{"persistedQuery":{"version":1,"sha256Hash":"cd7619a5186ef6277c1e82179c669e02e3edac97739593bc28fa32df5041d644"}}'
}
SPNONE = 'CH_7'
SPCHANNEL = 'ctSportExtra'
SPPREFIX = 'CH_'

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'
}


def get_sport_plus_channel(session):
    """Get current CT Sport Plus channel"""
    try:
        response = session.get(SPAPI, params=SPPARAMS, timeout=10)
        data = response.json()
        available = []
        if 'data' in data and data['data'] and 'liveBroadcastFind' in data['data'] and data['data']['liveBroadcastFind']:
            for live in data['data']['liveBroadcastFind']:
                if 'id' in live and live['id'] and 'current' in live and live['current'] and 'channel' in live['current'] and live['current']['channel'] and live['current']['channel'] == SPCHANNEL:
                    available.append(live['id'])
        if len(available) >= 1:
            return SPPREFIX + available[0]
    except:
        pass
    return SPNONE


def get_live_stream(channel_id):
    """Get live stream URL for CT channels"""
    session = requests.Session()
    session.headers.update(HEADERS)
    
    channel = channel_id
    
    # Handle channel mapping
    if channel in CHANNELS:
        channel_code = CHANNELS[channel]
    elif channel == 'ctsportplus':
        channel_code = get_sport_plus_channel(session)
    else:
        return None
    
    # Handle time-based channels (CT:D/art)
    if isinstance(channel_code, list):
        now = datetime.datetime.now().hour
        for chn in channel_code:
            if chn['from'] <= now < chn['to'] and chn['channel'] in CHANNELS:
                channel_code = CHANNELS[chn['channel']]
                break
    
    if isinstance(channel_code, list):
        return {'error': 'Could not determine channel'}
    
    try:
        response = session.get(API + channel_code, params=PARAMS, timeout=15)
        data = response.json()
        
        if 'streamUrls' in data and data['streamUrls'] and 'main' in data['streamUrls'] and data['streamUrls']['main']:
            return {
                'url': data['streamUrls']['main'],
                'manifest_type': 'hls',
                'headers': HEADERS
            }
        else:
            return {'error': 'No stream URL in response'}
    except Exception as e:
        return {'error': str(e)}
    
    return None
