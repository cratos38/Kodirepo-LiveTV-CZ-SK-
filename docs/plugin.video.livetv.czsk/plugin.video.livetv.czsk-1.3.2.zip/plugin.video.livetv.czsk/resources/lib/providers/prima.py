# -*- coding: utf-8 -*-
"""
Prima TV Provider - LIVE + CATCHUP
Based on waladir/plugin.video.primaplus for catchup API
License: AGPL v.3
"""

import requests
import re
import json
import time
import os

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

try:
    import xbmcaddon
    import xbmcvfs
    _addon = xbmcaddon.Addon()
    _profile = xbmcvfs.translatePath(_addon.getAddonInfo('profile'))
except:
    _addon = None
    _profile = None

PROXY_BASE = "http://p.6f.sk"
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'
}
CHANNELS = ['prima', 'love', 'krimi', 'max', 'cool', 'zoom', 'star', 'show']

# Prima+ channel IDs for catchup (from gateway-api)
PRIMA_CHANNEL_IDS = {
    'prima': 'prima',
    'primalove': 'love', 
    'primakrimi': 'krimi',
    'primamax': 'max',
    'primacool': 'cool',
    'primazoom': 'zoom',
    'primastar': 'star',
    'primashow': 'show',
    'cnnprimanews': 'cnn'
}


def get_prima_settings():
    """Get Prima login settings from addon"""
    if _addon:
        email = _addon.getSetting('prima_email') or ''
        password = _addon.getSetting('prima_password') or ''
        return email, password
    return '', ''


def get_token_file():
    """Get path to token cache file"""
    if _profile:
        return os.path.join(_profile, 'prima_token.json')
    return None


def save_token(token_data):
    """Save token to cache file"""
    token_file = get_token_file()
    if token_file:
        try:
            with open(token_file, 'w', encoding='utf-8') as f:
                json.dump(token_data, f)
        except:
            pass


def load_token():
    """Load token from cache file"""
    token_file = get_token_file()
    if token_file and os.path.exists(token_file):
        try:
            with open(token_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            pass
    return None


def get_prima_token():
    """
    Get Prima+ access token for catchup
    Requires registration at iprima.cz (free account works for some content)
    """
    # Check cached token
    cached = load_token()
    if cached and 'token' in cached and 'valid_to' in cached:
        if cached['valid_to'] > int(time.time()):
            return cached['token']
    
    # Get login credentials
    email, password = get_prima_settings()
    if not email or not password:
        return None
    
    try:
        headers = {'User-Agent': HEADERS['User-Agent']}
        response = requests.post(
            'https://ucet.iprima.cz/api/session/create',
            json={
                'email': email,
                'password': password,
                'deviceName': 'Kodi LiveTV CZ/SK'
            },
            headers=headers,
            timeout=15
        )
        data = response.json()
        
        if 'accessToken' in data:
            token = data['accessToken']['value']
            token_data = {
                'token': token,
                'valid_to': int(time.time()) + 7*60*60  # 7 hours validity
            }
            save_token(token_data)
            return token
    except Exception as e:
        print(f"[LiveTV CZ/SK] Prima token error: {e}")
    
    return None


def get_cnn_stream():
    """Get CNN Prima News stream (no login required)"""
    try:
        session = requests.Session()
        headers = {}
        headers.update(HEADERS)
        response = session.get(
            'https://api.play-backend.iprima.cz/api/v1/products/id-p650443/play',
            headers=headers,
            timeout=15
        )
        data = response.json()
        if 'streamInfos' in data and data['streamInfos']:
            stream = data['streamInfos'][0]['url']
            stream = stream.replace("_lq", "")
            return {
                'url': stream,
                'manifest_type': 'hls',
                'headers': HEADERS
            }
    except Exception as e:
        return {'error': str(e)}
    return None


def get_live_stream(channel_id):
    """Get live stream URL for Prima channels"""
    # CNN Prima News has special handling (no proxy needed)
    if channel_id == 'cnn' or channel_id == 'cnnprimanews':
        return get_cnn_stream()
    
    # Map channel names
    channel_map = {
        'prima': 'prima',
        'primalove': 'love',
        'primakrimi': 'krimi',
        'primamax': 'max',
        'primacool': 'cool',
        'primazoom': 'zoom',
        'primastar': 'star',
        'primashow': 'show'
    }
    
    channel = channel_map.get(channel_id, channel_id)
    
    if channel not in CHANNELS:
        return None
    
    try:
        session = requests.Session()
        headers = {}
        headers.update(HEADERS)
        
        # Load proxy index to keep it alive
        try:
            response = session.get(PROXY_BASE, headers=headers, timeout=10)
            content = response.text
            scripts = re.findall(r'<script[^>]*src=["\']([^"\']+)["\']', content)
            for src in scripts:
                if src.startswith("//"):
                    src = "http:" + src
                try:
                    session.get(src, headers=headers, timeout=5)
                except:
                    pass
        except:
            pass
        
        return {
            'url': PROXY_BASE + "/iprima.php?ch=" + channel,
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    except Exception as e:
        return {'error': str(e)}
    
    return None


def get_epg_channels():
    """Get list of Prima channels with EPG IDs for catchup"""
    token = get_prima_token()
    if not token:
        return None
    
    try:
        headers = {
            'Authorization': f'Bearer {token}',
            'X-OTT-Access-Token': token,
            'X-OTT-CDN-Url-Type': 'WEB',
            'User-Agent': HEADERS['User-Agent'],
            'Accept': 'application/json; charset=utf-8',
            'Content-type': 'application/json;charset=UTF-8'
        }
        
        post_data = {
            'id': '1',
            'jsonrpc': '2.0',
            'method': 'epg.channel.list',
            'params': {}
        }
        
        response = requests.post(
            'https://gateway-api.prod.iprima.cz/json-rpc/',
            json=post_data,
            headers=headers,
            timeout=15
        )
        data = response.json()
        
        if 'result' in data and 'data' in data['result']:
            return data['result']['data']
    except Exception as e:
        print(f"[LiveTV CZ/SK] Prima EPG channels error: {e}")
    
    return None


def get_epg_program(channel_id, day_offset=0):
    """
    Get EPG program for a Prima channel
    day_offset: 0 = today, -1 = yesterday, etc.
    """
    token = get_prima_token()
    if not token:
        return None
    
    try:
        from datetime import datetime, timedelta
        
        target_date = datetime.now() + timedelta(days=day_offset)
        date_str = target_date.strftime('%Y-%m-%d')
        
        headers = {
            'Authorization': f'Bearer {token}',
            'X-OTT-Access-Token': token,
            'X-OTT-CDN-Url-Type': 'WEB',
            'User-Agent': HEADERS['User-Agent'],
            'Accept': 'application/json; charset=utf-8',
            'Content-type': 'application/json;charset=UTF-8'
        }
        
        post_data = {
            'id': '1',
            'jsonrpc': '2.0',
            'method': 'epg.program.list',
            'params': {
                'channelId': channel_id,
                'date': date_str
            }
        }
        
        response = requests.post(
            'https://gateway-api.prod.iprima.cz/json-rpc/',
            json=post_data,
            headers=headers,
            timeout=15
        )
        data = response.json()
        
        if 'result' in data and 'data' in data['result']:
            return data['result']['data']
    except Exception as e:
        print(f"[LiveTV CZ/SK] Prima EPG program error: {e}")
    
    return None


def find_program_by_timestamp(channel_id, utc_timestamp):
    """
    Find a program in Prima archive by UTC timestamp
    Returns the playId if found
    """
    from datetime import datetime, timedelta
    
    # Convert UTC timestamp to datetime
    program_time = datetime.utcfromtimestamp(int(utc_timestamp))
    
    # Search in the past 7 days
    for day_offset in range(0, -8, -1):
        programs = get_epg_program(channel_id, day_offset)
        if not programs:
            continue
        
        for program in programs:
            try:
                start_str = program.get('programStartTime', '')[:19]
                end_str = program.get('programEndTime', '')[:19]
                
                start_time = datetime.strptime(start_str, '%Y-%m-%dT%H:%M:%S')
                end_time = datetime.strptime(end_str, '%Y-%m-%dT%H:%M:%S')
                
                # Check if the timestamp falls within this program
                if start_time <= program_time <= end_time:
                    if program.get('isPlayable') and program.get('playId'):
                        return program['playId']
            except:
                continue
    
    return None


def get_catchup_stream(channel_id, utc_timestamp):
    """
    Get catchup/archive stream for Prima channels
    Requires Prima+ account (free registration works for some content)
    
    Args:
        channel_id: Channel identifier (prima, primalove, etc.)
        utc_timestamp: Unix timestamp of the program start time
    
    Returns:
        dict with 'url', 'manifest_type', 'headers' or 'error'
    """
    token = get_prima_token()
    if not token:
        return {
            'error': 'Prima+ catchup vyžaduje přihlášení. Nastavte email a heslo v nastaveních doplňku.'
        }
    
    # Map our channel_id to Prima's internal channel_id
    # This needs to be discovered from the EPG API
    prima_channel_map = {
        'prima': 'p100001',  # These IDs need to be confirmed
        'primalove': 'p100006',
        'primakrimi': 'p100005',
        'primamax': 'p100003',
        'primacool': 'p100002',
        'primazoom': 'p100004',
        'primastar': 'p100007',
        'primashow': 'p100008',
        'cnnprimanews': 'p100009'
    }
    
    # First, try to get channels list to find correct ID
    channels = get_epg_channels()
    if channels:
        for ch in channels:
            ch_title = ch.get('title', '').lower()
            ch_id = ch.get('id', '')
            
            # Try to match by name
            if channel_id in ch_title or ch_title in channel_id:
                prima_channel_map[channel_id] = ch_id
                break
    
    prima_channel_id = prima_channel_map.get(channel_id)
    if not prima_channel_id:
        return {'error': f'Neznámý kanál pro catchup: {channel_id}'}
    
    # Find the program playId by timestamp
    play_id = find_program_by_timestamp(prima_channel_id, utc_timestamp)
    if not play_id:
        return {'error': 'Program nebyl nalezen v archivu Prima+'}
    
    # Get the stream URL using the playId
    try:
        headers = {
            'Authorization': f'Bearer {token}',
            'X-OTT-Access-Token': token,
            'X-OTT-CDN-Url-Type': 'WEB',
            'User-Agent': HEADERS['User-Agent'],
            'Accept': 'application/json; charset=utf-8',
            'Content-type': 'application/json;charset=UTF-8'
        }
        
        response = requests.get(
            f'https://api.play-backend.iprima.cz/api/v1/products/id-{play_id}/play',
            headers=headers,
            timeout=15
        )
        data = response.json()
        
        if 'streamInfos' in data and data['streamInfos']:
            # Prefer HLS stream
            stream_url = None
            for stream in data['streamInfos']:
                if stream.get('type') == 'HLS' and stream.get('url'):
                    stream_url = stream['url']
                    break
            
            if not stream_url:
                stream_url = data['streamInfos'][0].get('url')
            
            if stream_url:
                # Remove low quality suffix if present
                stream_url = stream_url.replace('_lq', '')
                
                return {
                    'url': stream_url,
                    'manifest_type': 'hls',
                    'headers': HEADERS
                }
        
        # Check for DRM requirement
        if 'error' in data or not data.get('streamInfos'):
            return {
                'error': 'Tento pořad není dostupný (možná vyžaduje Prima+ předplatné)'
            }
            
    except Exception as e:
        return {'error': f'Chyba při získávání streamu: {str(e)}'}
    
    return {'error': 'Stream nenalezen'}
