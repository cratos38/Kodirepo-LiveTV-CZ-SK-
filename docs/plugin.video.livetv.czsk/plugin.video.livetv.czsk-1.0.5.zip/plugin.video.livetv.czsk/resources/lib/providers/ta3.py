# -*- coding: utf-8 -*-
# Based on cache-sk's freeview.sk ta3 provider
# License: AGPL v.3

import requests
import re

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

CHANNELS = {
    'ta3': 'https://embed.livebox.cz/ta3_v2/live-source.js'
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'
}


def get_live_stream(channel_id):
    """Get live stream URL for TA3"""
    if channel_id not in CHANNELS:
        return None
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        response = session.get(CHANNELS[channel_id], timeout=15)
        content = response.content
        try:
            content = content.decode('utf-8')
        except AttributeError:
            pass
        
        # Find stream URL
        matches = re.findall(r'"src" : "([^}]*)"', content)
        src = None
        for match in matches:
            if '1.smil' in match:
                src = match
                break
        
        if src:
            src = src.replace('|', '%7C')
            if src.startswith('//'):
                src = 'https:' + src
            
            return {
                'url': src,
                'manifest_type': 'hls',
                'headers': HEADERS
            }
    except Exception as e:
        return {'error': str(e)}
    
    return None
