# -*- coding: utf-8 -*-
"""
Channel definitions for LiveTV - CZ/SK
Based on Freeview.sk playlist - only channels that work
"""

CHANNELS = {
    # ============ RTVS (Slovak) - WORKING ============
    'jednotka': {
        'name': 'Jednotka',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': 'jednotka.png',
    },
    'dvojka': {
        'name': 'Dvojka',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': 'dvojka.png',
    },
    'stv24': {
        'name': ':24',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': '24.png',
    },
    'rtvssport': {
        'name': 'RTVS Sport',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': 'sport.png',
    },
    'rtvsonline': {
        'name': 'Live :O',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': 'rtvs.png',
    },
    'rtvslive': {
        'name': 'Live RTVS',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': 'rtvs.png',
    },
    'nrsr': {
        'name': 'Live NRSR',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': 'nrsr.png',
    },
    
    # ============ JOJ (Slovak) - WORKING ============
    'joj': {
        'name': 'JOJ',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'joj.png',
    },
    'jojplus': {
        'name': 'JOJ Plus',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'plus.png',
    },
    'jojwau': {
        'name': 'WAU',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'wau.png',
    },
    'jojsport': {
        'name': 'JOJ Sport',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojsport.png',
    },
    'jojsport2': {
        'name': 'JOJ Sport 2',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojsport2.png',
    },
    'jojfamily': {
        'name': 'JOJ Family',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'family.png',
    },
    'jojko': {
        'name': 'JOJko',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojko.png',
    },
    'joj24': {
        'name': 'JOJ 24',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'joj24.png',
    },
    'jojcinema': {
        'name': 'JOJ Cinema',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojcinema.png',
    },
    
    # ============ CS LINK (via JOJ) - WORKING ============
    'csfilm': {
        'name': 'CS Film',
        'provider': 'joj',
        'country': 'CZ',
        'group': 'CS Link',
        'logo': 'csfilm.png',
    },
    'cshistory': {
        'name': 'CS History',
        'provider': 'joj',
        'country': 'CZ',
        'group': 'CS Link',
        'logo': 'cshistory.png',
    },
    'csmystery': {
        'name': 'CS Mystery',
        'provider': 'joj',
        'country': 'CZ',
        'group': 'CS Link',
        'logo': 'csmystery.png',
    },
    
    # ============ TA3 (Slovak News) - WORKING ============
    'ta3': {
        'name': 'TA3',
        'provider': 'ta3',
        'country': 'SK',
        'group': 'News',
        'logo': 'ta3.png',
    },
    
    # ============ CESKA TELEVIZE (CT) - WORKING ============
    'ct1': {
        'name': 'CT1',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ct1.png',
    },
    'ct2': {
        'name': 'CT2',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ct2.png',
    },
    'ct24': {
        'name': 'CT24',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ct24.png',
    },
    'ctsport': {
        'name': 'CT Sport',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ctsport.png',
    },
    'ctdart': {
        'name': 'CT :D/art',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ctdart.png',
    },
    
    # ============ NOVA - WORKING (with IP spoof) ============
    'novacinema': {
        'name': 'Nova Cinema',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novacinema.png',
    },
    'novasport1': {
        'name': 'Nova Sport 1',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novasport1.png',
    },
    'novasport2': {
        'name': 'Nova Sport 2',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novasport2.png',
    },
    
    # ============ PRIMA - WORKING (via proxy) ============
    'prima': {
        'name': 'Prima',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'prima.png',
    },
    'primacool': {
        'name': 'Prima Cool',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primacool.png',
    },
    'primamax': {
        'name': 'Prima Max',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primamax.png',
    },
    'primakrimi': {
        'name': 'Prima Krimi',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primakrimi.png',
    },
    'primalove': {
        'name': 'Prima Love',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primalove.png',
    },
    'primazoom': {
        'name': 'Prima Zoom',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primazoom.png',
    },
    'primastar': {
        'name': 'Prima Star',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primastar.png',
    },
    'primashow': {
        'name': 'Prima Show',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primashow.png',
    },
    'cnnprimanews': {
        'name': 'CNN Prima News',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'cnnprimanews.png',
    },
    
    # ============ OCKO (Music) - WORKING ============
    'ocko': {
        'name': 'Ocko',
        'provider': 'ocko',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'ocko.png',
    },
    'ockoexpres': {
        'name': 'Ocko Expres',
        'provider': 'ocko',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'ockoexpress.png',
    },
    'ockostar': {
        'name': 'Ocko Star',
        'provider': 'ocko',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'ockostar.png',
    },
    
    # ============ OTHER - WORKING ============
    'fashion': {
        'name': 'Fashion TV',
        'provider': 'simple',
        'country': 'INT',
        'group': 'Other',
        'logo': 'fashion.png',
    },
    'doktor': {
        'name': 'TV Doktor',
        'provider': 'simple',
        'country': 'SK',
        'group': 'Other',
        'logo': 'drtv.png',
    },
    'szts': {
        'name': 'SZTS',
        'provider': 'simple',
        'country': 'SK',
        'group': 'Other',
        'logo': 'szts.png',
    },
}


def get_all_channels():
    """Return all channels sorted alphabetically"""
    return dict(sorted(CHANNELS.items(), key=lambda x: x[1]['name'].lower()))


def get_channel(channel_id):
    """Get channel info by ID"""
    return CHANNELS.get(channel_id)
