# -*- coding: utf-8 -*-
# Based on cache-sk's freeview.sk prima provider
# License: AGPL v.3

import requests
from bs4 import BeautifulSoup

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

PROXY_BASE = "http://p.6f.sk"
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'
}
CHANNELS = ['prima', 'love', 'krimi', 'max', 'cool', 'zoom', 'star', 'show']


def get_cnn_stream():
    """Get CNN Prima News stream"""
    try:
        session = requests.Session()
        headers = {}
        headers.update(HEADERS)
        response = session.get('https://api.play-backend.iprima.cz/api/v1/products/id-p650443/play', headers=headers, timeout=15)
        data = response.json()
        if 'streamInfos' in data and data['streamInfos']:
            stream = data['streamInfos'][0]['url']
            stream = stream.replace("_lq", "")  # remove lq profile
            return {
                'url': stream,
                'manifest_type': 'hls',
                'headers': HEADERS
            }
    except Exception as e:
        return {'error': str(e)}
    return None


def get_live_stream(channel_id):
    """Get live stream URL for Prima channels"""
    # CNN Prima News has special handling
    if channel_id == 'cnn' or channel_id == 'cnnprimanews':
        return get_cnn_stream()
    
    # Map channel names
    channel_map = {
        'prima': 'prima',
        'primalove': 'love',
        'primakrimi': 'krimi',
        'primamax': 'max',
        'primacool': 'cool',
        'primazoom': 'zoom',
        'primastar': 'star',
        'primashow': 'show'
    }
    
    channel = channel_map.get(channel_id, channel_id)
    
    if channel not in CHANNELS:
        return None
    
    try:
        session = requests.Session()
        headers = {}
        headers.update(HEADERS)
        
        # Load proxy index to keep it alive
        try:
            response = session.get(PROXY_BASE, headers=headers, timeout=10)
            html = BeautifulSoup(response.content, features="html.parser")
            items = html.find_all('script', {}, True)
            for item in items:
                if item.has_attr('src'):
                    src = item["src"]
                    if src.startswith("//"):
                        src = "http:" + src
                    session.get(src, headers=headers, timeout=5)
        except:
            pass
        
        return {
            'url': PROXY_BASE + "/iprima.php?ch=" + channel,
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    except Exception as e:
        return {'error': str(e)}
    
    return None
