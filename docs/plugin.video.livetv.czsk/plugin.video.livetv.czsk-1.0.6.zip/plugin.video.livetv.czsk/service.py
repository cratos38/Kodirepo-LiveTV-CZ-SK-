# -*- coding: utf-8 -*-
"""
LiveTV - CZ/SK
Background service for EPG updates
"""
import os
import time
import xbmc
import xbmcaddon
import xbmcvfs


class LiveTVService(xbmc.Monitor):
    """Background service for LiveTV CZ/SK"""
    
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.addon = xbmcaddon.Addon()
        self.addon_id = self.addon.getAddonInfo('id')
        self.profile_path = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        
        # Create profile directory if needed
        if not os.path.exists(self.profile_path):
            os.makedirs(self.profile_path)
        
        self.log('Service started')
    
    def log(self, message, level=xbmc.LOGINFO):
        """Log message to Kodi log"""
        xbmc.log(f'[LiveTV CZ/SK Service] {message}', level)
    
    def onSettingsChanged(self):
        """Called when addon settings change"""
        self.addon = xbmcaddon.Addon()  # Refresh
        self.log('Settings changed')
    
    def run(self):
        """Main service loop"""
        self.log('Service running')
        
        # Initial delay
        wait_time = 60  # Check every minute
        
        while not self.abortRequested():
            # Wait for abort or timeout
            if self.waitForAbort(wait_time):
                break
            
            # Future: EPG update logic will go here
            # For now, just keep the service alive
        
        self.log('Service stopped')


if __name__ == '__main__':
    service = LiveTVService()
    service.run()
