# -*- coding: utf-8 -*-
"""
Provider: Prima (Czech commercial TV)
LIVE TV - Uses proxy/redirect streams
Note: Catchup to be implemented in Phase 3
"""
import re
import json

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Origin': 'https://www.iprima.cz',
    'Referer': 'https://www.iprima.cz/'
}

# Prima channels - using known working streams
# These may need updating as Prima changes their infrastructure
CHANNEL_STREAMS = {
    'prima': {
        'name': 'Prima',
        'stream_url': None,  # Needs proxy
        'web_url': 'https://www.iprima.cz/tv-kanaly/prima'
    },
    'primacool': {
        'name': 'Prima Cool',
        'stream_url': None,
        'web_url': 'https://www.iprima.cz/tv-kanaly/cool'
    },
    'primamax': {
        'name': 'Prima Max',
        'stream_url': None,
        'web_url': 'https://www.iprima.cz/tv-kanaly/max'
    },
    'primakrimi': {
        'name': 'Prima Krimi',
        'stream_url': None,
        'web_url': 'https://www.iprima.cz/tv-kanaly/krimi'
    },
    'primalove': {
        'name': 'Prima Love',
        'stream_url': None,
        'web_url': 'https://www.iprima.cz/tv-kanaly/love'
    },
    'primazoom': {
        'name': 'Prima Zoom',
        'stream_url': None,
        'web_url': 'https://www.iprima.cz/tv-kanaly/zoom'
    },
    'primastar': {
        'name': 'Prima Star',
        'stream_url': None,
        'web_url': 'https://www.iprima.cz/tv-kanaly/star'
    },
    'primashow': {
        'name': 'Prima Show',
        'stream_url': None,
        'web_url': 'https://www.iprima.cz/tv-kanaly/show'
    },
    'cnnprima': {
        'name': 'CNN Prima News',
        'stream_url': 'https://cnn.cz/api/live/playlist.m3u8',  # Direct stream available
        'web_url': 'https://cnn.iprima.cz/'
    }
}

# Proxy URL for Prima streams (from freeview.sk)
# This proxies through a server that handles Prima's authentication
PROXY_BASE = 'http://p.xf.cz/fget.php?url='


def get_live_stream(channel_id):
    """
    Get live stream URL for Prima channel
    
    Prima requires special handling - streams are not directly accessible
    and need to go through a proxy or be extracted from their web player
    
    Args:
        channel_id: Channel identifier
        
    Returns:
        dict with 'url' and 'manifest_type' or None
    """
    import requests
    
    channel_data = CHANNEL_STREAMS.get(channel_id)
    if not channel_data:
        return None
    
    # If we have a direct stream URL (like CNN Prima)
    if channel_data.get('stream_url'):
        return {
            'url': channel_data['stream_url'],
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    
    # For other Prima channels, we need to extract from web
    # This is complex and may not always work
    try:
        return _extract_prima_stream(channel_id, channel_data)
    except Exception as e:
        print(f"[Prima Provider] Error: {e}")
        return None


def _extract_prima_stream(channel_id, channel_data):
    """
    Try to extract Prima stream from web page
    This is fragile and may break when Prima changes their site
    """
    import requests
    
    session = requests.Session()
    session.headers.update(HEADERS)
    
    try:
        # Get the channel page
        response = session.get(channel_data['web_url'], timeout=15)
        response.raise_for_status()
        html = response.text
        
        # Try to find stream URL in page
        # Prima embeds player with stream info
        
        # Pattern 1: Look for m3u8 URL
        m3u8_pattern = r'(https?://[^\s"\']+\.m3u8[^\s"\']*)'
        matches = re.findall(m3u8_pattern, html)
        
        for match in matches:
            if 'prima' in match.lower() or 'cdn' in match.lower():
                # Validate stream
                try:
                    test = session.head(match, timeout=5)
                    if test.status_code == 200:
                        return {
                            'url': match,
                            'manifest_type': 'hls',
                            'headers': HEADERS
                        }
                except:
                    continue
        
        # Pattern 2: Look for player config
        config_pattern = r'playerConfig\s*=\s*({[^}]+})'
        config_match = re.search(config_pattern, html)
        if config_match:
            try:
                config = json.loads(config_match.group(1))
                if 'streamUrl' in config:
                    return {
                        'url': config['streamUrl'],
                        'manifest_type': 'hls',
                        'headers': HEADERS
                    }
            except:
                pass
        
        # Pattern 3: iframe embed
        iframe_pattern = r'<iframe[^>]+src=["\']([^"\']+prima[^"\']*)["\']'
        iframe_match = re.search(iframe_pattern, html, re.IGNORECASE)
        if iframe_match:
            iframe_url = iframe_match.group(1)
            return _extract_from_iframe(session, iframe_url)
        
    except Exception as e:
        print(f"[Prima Provider] Extraction failed: {e}")
    
    return None


def _extract_from_iframe(session, iframe_url):
    """Extract stream from Prima iframe player"""
    try:
        response = session.get(iframe_url, timeout=15)
        html = response.text
        
        # Look for HLS stream
        m3u8_pattern = r'(https?://[^\s"\']+\.m3u8[^\s"\']*)'
        matches = re.findall(m3u8_pattern, html)
        
        for match in matches:
            return {
                'url': match,
                'manifest_type': 'hls',
                'headers': HEADERS
            }
    except:
        pass
    
    return None


def get_catchup_stream(channel_id, utc_timestamp):
    """
    Get catchup stream for Prima
    TODO: Implement in Phase 3
    Prima has an API for this but requires investigation
    """
    return {'error': 'Prima catchup not yet implemented'}
