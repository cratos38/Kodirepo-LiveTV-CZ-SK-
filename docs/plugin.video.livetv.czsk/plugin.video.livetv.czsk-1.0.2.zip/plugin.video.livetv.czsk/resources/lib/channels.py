# -*- coding: utf-8 -*-
"""
Channel definitions for LiveTV - CZ/SK
Complete list based on freeview.sk + Barrandov
EPG IDs mapped to iptv-epg.org
"""

# All channels with their properties
CHANNELS = {
    # =====================================================
    # CZECH CHANNELS
    # =====================================================
    
    # ----------------
    # CT - Ceska televize (with catch-up support)
    # ----------------
    'ct1': {
        'name': 'CT1',
        'provider': 'ct',
        'country': 'cz',
        'group': 'Ceska televize',
        'logo': 'ct1.png',
        'epg_id': 'CT1.cz',
        'epg_id_iptv': '344804928',
        'catchup': True,
        'catchup_days': 7
    },
    'ct2': {
        'name': 'CT2',
        'provider': 'ct',
        'country': 'cz',
        'group': 'Ceska televize',
        'logo': 'ct2.png',
        'epg_id': 'CT2.cz',
        'epg_id_iptv': '344804992',
        'catchup': True,
        'catchup_days': 7
    },
    'ct24': {
        'name': 'CT24',
        'provider': 'ct',
        'country': 'cz',
        'group': 'Ceska televize',
        'logo': 'ct24.png',
        'epg_id': 'CT24.cz',
        'epg_id_iptv': '343997248',
        'catchup': True,
        'catchup_days': 7
    },
    'ctsport': {
        'name': 'CT Sport',
        'provider': 'ct',
        'country': 'cz',
        'group': 'Ceska televize',
        'logo': 'ctsport.png',
        'epg_id': 'CTsport.cz',
        'epg_id_iptv': '344812096',
        'catchup': True,
        'catchup_days': 7
    },
    'ctdart': {
        'name': 'CT:D/art',
        'provider': 'ct',
        'country': 'cz',
        'group': 'Ceska televize',
        'logo': 'ctdart.png',
        'epg_id': 'CTD.cz',
        'epg_id_iptv': '344805248',
        'catchup': True,
        'catchup_days': 7
    },
    
    # ----------------
    # Prima
    # ----------------
    'prima': {
        'name': 'Prima',
        'provider': 'prima',
        'country': 'cz',
        'group': 'Prima',
        'logo': 'prima.png',
        'epg_id': 'PRIMA.cz',
        'epg_id_iptv': '344805120',
        'catchup': False
    },
    'primacool': {
        'name': 'Prima Cool',
        'provider': 'prima',
        'country': 'cz',
        'group': 'Prima',
        'logo': 'primacool.png',
        'epg_id': 'PRIMACOOL.cz',
        'epg_id_iptv': '344812416',
        'catchup': False
    },
    'primamax': {
        'name': 'Prima Max',
        'provider': 'prima',
        'country': 'cz',
        'group': 'Prima',
        'logo': 'primamax.png',
        'epg_id': 'PRIMAMAX.cz',
        'epg_id_iptv': '344723136',
        'catchup': False
    },
    'primakrimi': {
        'name': 'Prima Krimi',
        'provider': 'prima',
        'country': 'cz',
        'group': 'Prima',
        'logo': 'primakrimi.png',
        'epg_id': 'PRIMAKRIMI.cz',
        'epg_id_iptv': '344854784',
        'catchup': False
    },
    'primalove': {
        'name': 'Prima Love',
        'provider': 'prima',
        'country': 'cz',
        'group': 'Prima',
        'logo': 'primalove.png',
        'epg_id': 'PRIMALOVE.cz',
        'epg_id_iptv': '344805632',
        'catchup': False
    },
    'primazoom': {
        'name': 'Prima Zoom',
        'provider': 'prima',
        'country': 'cz',
        'group': 'Prima',
        'logo': 'primazoom.png',
        'epg_id': 'PRIMAZOOM.cz',
        'epg_id_iptv': '344805696',
        'catchup': False
    },
    'primastar': {
        'name': 'Prima Star',
        'provider': 'prima',
        'country': 'cz',
        'group': 'Prima',
        'logo': 'primastar.png',
        'epg_id': 'PRIMASTAR.cz',
        'epg_id_iptv': '344939456',
        'catchup': False
    },
    'primashow': {
        'name': 'Prima Show',
        'provider': 'prima',
        'country': 'cz',
        'group': 'Prima',
        'logo': 'primashow.png',
        'epg_id': 'PRIMASHOW.cz',
        'epg_id_iptv': '344946240',
        'catchup': False
    },
    'cnnprima': {
        'name': 'CNN Prima News',
        'provider': 'prima',
        'country': 'cz',
        'group': 'Prima',
        'logo': 'cnnprimanews.png',
        'epg_id': 'CNNPRIMANEWS.cz',
        'epg_id_iptv': '344913920',
        'catchup': False
    },
    
    # ----------------
    # Nova
    # ----------------
    'nova': {
        'name': 'Nova',
        'provider': 'nova',
        'country': 'cz',
        'group': 'Nova',
        'logo': 'nova.png',
        'epg_id': 'NOVA.cz',
        'epg_id_iptv': '344805056',
        'catchup': False
    },
    'novacinema': {
        'name': 'Nova Cinema',
        'provider': 'nova',
        'country': 'cz',
        'group': 'Nova',
        'logo': 'novacinema.png',
        'epg_id': 'NOVACINEMA.cz',
        'epg_id_iptv': '344805312',
        'catchup': False
    },
    'novasport1': {
        'name': 'Nova Sport 1',
        'provider': 'nova',
        'country': 'cz',
        'group': 'Nova',
        'logo': 'novasport1.png',
        'epg_id': 'NOVASPORT1.cz',
        'epg_id_iptv': '344808000',
        'catchup': False
    },
    'novasport2': {
        'name': 'Nova Sport 2',
        'provider': 'nova',
        'country': 'cz',
        'group': 'Nova',
        'logo': 'novasport2.png',
        'epg_id': 'NOVASPORT2.cz',
        'epg_id_iptv': '344816320',
        'catchup': False
    },
    
    # ----------------
    # Barrandov
    # ----------------
    'barrandov': {
        'name': 'TV Barrandov',
        'provider': 'generic',
        'country': 'cz',
        'group': 'Barrandov',
        'logo': 'barrandov.png',
        'epg_id': 'TVBARRANDOV.cz',
        'stream_url': 'https://stream-25.mazana.tv/barrandov.m3u8',
        'catchup': False
    },
    'barrandovkino': {
        'name': 'Kino Barrandov',
        'provider': 'generic',
        'country': 'cz',
        'group': 'Barrandov',
        'logo': 'kinobarrandov.png',
        'epg_id': 'KINOBARRANDOV.cz',
        'stream_url': 'http://83.167.253.107/hdmi1_ext',
        'catchup': False
    },
    
    # ----------------
    # Music channels CZ
    # ----------------
    'ocko': {
        'name': 'Ocko',
        'provider': 'generic',
        'country': 'cz',
        'group': 'Music',
        'logo': 'ocko.png',
        'epg_id': 'OCKO.cz',
        'epg_id_iptv': '343998016',
        'stream_url': 'https://ocko-live-dash.ssl.cdn.cra.cz/cra_live2/ocko.stream.1.smil/playlist.m3u8',
        'catchup': False
    },
    'ockoexpres': {
        'name': 'Ocko Expres',
        'provider': 'generic',
        'country': 'cz',
        'group': 'Music',
        'logo': 'ockoexpress.png',
        'epg_id': 'OCKOEXPRES.cz',
        'epg_id_iptv': '344906688',
        'stream_url': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8',
        'catchup': False
    },
    'ockostar': {
        'name': 'Ocko Star',
        'provider': 'generic',
        'country': 'cz',
        'group': 'Music',
        'logo': 'ockostar.png',
        'epg_id': 'OCKOSTAR.cz',
        'epg_id_iptv': '344841856',
        'stream_url': 'https://ocko-live.ssl.cdn.cra.cz/cra_live2/ocko_gold.stream.1.smil/playlist.m3u8',
        'catchup': False
    },
    'retromusic': {
        'name': 'Retro Music TV',
        'provider': 'generic',
        'country': 'cz',
        'group': 'Music',
        'logo': 'retro.png',
        'epg_id': 'RETROMUSICTV.cz',
        'stream_url': 'https://stream.mediawork.cz/retrotv/retrotvHQ1/playlist.m3u8',
        'catchup': False
    },
    
    # =====================================================
    # SLOVAK CHANNELS  
    # =====================================================
    
    # ----------------
    # RTVS - Slovak public TV
    # ----------------
    'jednotka': {
        'name': 'Jednotka',
        'provider': 'rtvs',
        'country': 'sk',
        'group': 'RTVS',
        'logo': 'jednotka.png',
        'epg_id': 'JEDNOTKA.cz',
        'epg_id_iptv': '2458735488',
        'catchup': True,
        'catchup_days': 7
    },
    'dvojka': {
        'name': 'Dvojka',
        'provider': 'rtvs',
        'country': 'sk',
        'group': 'RTVS',
        'logo': 'dvojka.png',
        'epg_id': 'DVOJKA.cz',
        'epg_id_iptv': '2458735552',
        'catchup': True,
        'catchup_days': 7
    },
    'rtvs24': {
        'name': ':24',
        'provider': 'rtvs',
        'country': 'sk',
        'group': 'RTVS',
        'logo': '24.png',
        'epg_id': 'STV24.cz',
        'epg_id_iptv': '2458840320',
        'catchup': True,
        'catchup_days': 7
    },
    'rtvssport': {
        'name': 'RTVS Sport',
        'provider': 'rtvs',
        'country': 'sk',
        'group': 'RTVS',
        'logo': 'sport.png',
        'epg_id': 'RTVSSPORT.sk',
        'catchup': True,
        'catchup_days': 7
    },
    
    # ----------------
    # JOJ
    # ----------------
    'joj': {
        'name': 'JOJ',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'joj.png',
        'epg_id': 'JOJ.cz',
        'epg_id_iptv': '2458735680',
        'catchup': False
    },
    'jojplus': {
        'name': 'JOJ Plus',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'plus.png',
        'epg_id': 'JOJPLUS.cz',
        'epg_id_iptv': '2458735744',
        'catchup': False
    },
    'wau': {
        'name': 'WAU',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'wau.png',
        'epg_id': 'WAU.sk',
        'catchup': False
    },
    'jojfamily': {
        'name': 'JOJ Family',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'family.png',
        'epg_id': 'JOJFAMILY.cz',
        'epg_id_iptv': '344823488',
        'catchup': False
    },
    'jojko': {
        'name': 'JOJko',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'jojko.png',
        'epg_id': 'JOJKO.cz',
        'epg_id_iptv': '2458739584',
        'catchup': False
    },
    'joj24': {
        'name': 'JOJ 24',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'joj24.png',
        'epg_id': 'JOJ24.cz',
        'epg_id_iptv': '2458881472',
        'catchup': False
    },
    'jojcinema': {
        'name': 'JOJ Cinema',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'jojcinema.png',
        'epg_id': 'JOJCINEMA.cz',
        'epg_id_iptv': '344806784',
        'catchup': False
    },
    'jojsport': {
        'name': 'JOJ Sport',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'jojsport.png',
        'epg_id': 'JOJSPORT.cz',
        'epg_id_iptv': '2458874496',
        'catchup': False
    },
    
    # ----------------
    # CS Channels (JOJ group)
    # ----------------
    'csfilm': {
        'name': 'CS Film',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'csfilm.png',
        'epg_id': 'CSFILM.cz',
        'epg_id_iptv': '344806848',
        'catchup': False
    },
    'cshistory': {
        'name': 'CS History',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'cshistory.png',
        'epg_id': 'CSHISTORY.cz',
        'epg_id_iptv': '344841792',
        'catchup': False
    },
    'csmystery': {
        'name': 'CS Mystery',
        'provider': 'joj',
        'country': 'sk',
        'group': 'JOJ',
        'logo': 'csmystery.png',
        'epg_id': 'CSMYSTERY.cz',
        'epg_id_iptv': '344809472',
        'catchup': False
    },
    
    # ----------------
    # Markiza (streams don't work - captcha protection)
    # Included for EPG completeness
    # ----------------
    'markiza': {
        'name': 'Markiza',
        'provider': 'markiza',
        'country': 'sk',
        'group': 'Markiza',
        'logo': 'markiza.png',
        'epg_id': 'MARKIZA.cz',
        'epg_id_iptv': '2458735616',
        'enabled': False,  # Streams don't work
        'catchup': False
    },
    'markizakrimi': {
        'name': 'Markiza Krimi',
        'provider': 'markiza',
        'country': 'sk',
        'group': 'Markiza',
        'logo': 'krimi.png',
        'epg_id': 'MARKIZA_KRIMI.cz',
        'epg_id_iptv': '2458879488',
        'enabled': False,
        'catchup': False
    },
    'markizaklasik': {
        'name': 'Markiza Klasik',
        'provider': 'markiza',
        'country': 'sk',
        'group': 'Markiza',
        'logo': 'klasik.png',
        'epg_id': 'MarkizaKlasik.cz',
        'epg_id_iptv': '2458903616',
        'enabled': False,
        'catchup': False
    },
    'doma': {
        'name': 'Doma',
        'provider': 'markiza',
        'country': 'sk',
        'group': 'Markiza',
        'logo': 'doma.png',
        'epg_id': 'DOMA.sk',
        'enabled': False,
        'catchup': False
    },
    'dajto': {
        'name': 'Dajto',
        'provider': 'markiza',
        'country': 'sk',
        'group': 'Markiza',
        'logo': 'dajto.png',
        'epg_id': 'DAJTO.sk',
        'enabled': False,
        'catchup': False
    },
    
    # ----------------
    # TA3 - News
    # ----------------
    'ta3': {
        'name': 'TA3',
        'provider': 'ta3',
        'country': 'sk',
        'group': 'News',
        'logo': 'ta3.png',
        'epg_id': 'TA3.cz',
        'epg_id_iptv': '2457865600',
        'catchup': False
    },
}


def get_channels_by_country(country):
    """Get channels filtered by country (cz/sk)"""
    return {k: v for k, v in CHANNELS.items() 
            if v.get('country') == country and v.get('enabled', True)}


def get_channels_by_provider(provider):
    """Get channels filtered by provider"""
    return {k: v for k, v in CHANNELS.items() 
            if v.get('provider') == provider and v.get('enabled', True)}


def get_channels_by_group(group):
    """Get channels filtered by group"""
    return {k: v for k, v in CHANNELS.items() 
            if v.get('group') == group and v.get('enabled', True)}


def get_all_channels():
    """Get all enabled channels"""
    return {k: v for k, v in CHANNELS.items() if v.get('enabled', True)}


def get_channel(channel_id):
    """Get single channel by ID"""
    ch = CHANNELS.get(channel_id)
    if ch and ch.get('enabled', True):
        return ch
    return None


def get_epg_mapping():
    """Get mapping of EPG IDs for iptv-epg.org integration"""
    mapping = {}
    for ch_id, ch_info in CHANNELS.items():
        if 'epg_id_iptv' in ch_info:
            mapping[ch_info['epg_id_iptv']] = ch_info.get('epg_id', ch_id)
    return mapping
