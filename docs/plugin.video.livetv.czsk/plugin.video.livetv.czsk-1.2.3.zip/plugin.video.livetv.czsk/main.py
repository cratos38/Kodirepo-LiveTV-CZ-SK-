# -*- coding: utf-8 -*-
"""
LiveTV - CZ/SK
Main entry point for the Kodi addon
Author: cratos38
License: AGPL-3.0
"""
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

try:
    from urllib.parse import urlencode, parse_qsl, quote_plus
except ImportError:
    from urllib import urlencode, quote_plus
    from urlparse import parse_qsl

# Add lib folder to path
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ADDON_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
sys.path.insert(0, os.path.join(ADDON_PATH, 'resources', 'lib'))

from channels import get_all_channels, get_channel
from providers import ct, rtvs, prima, joj, ta3, nova, generic, ocko, simple, markiza

# Plugin handle
_URL = sys.argv[0]
_HANDLE = int(sys.argv[1])

# Logo path
LOGO_PATH = os.path.join(ADDON_PATH, 'resources', 'logos')


def get_url(**kwargs):
    """Build plugin URL with parameters"""
    return '{0}?{1}'.format(_URL, urlencode(kwargs))


def show_main_menu():
    """Show main menu with options"""
    xbmcplugin.setPluginCategory(_HANDLE, 'LiveTV - CZ/SK')
    xbmcplugin.setContent(_HANDLE, 'files')
    
    # Menu items
    menu_items = [
        {
            'label': '[B]► Ver Canales[/B]',
            'action': 'list_channels',
            'icon': 'DefaultTVShows.png',
            'description': 'Ver lista de canales de TV'
        },
        {
            'label': '[COLOR yellow]⟳ Regenerar EPG[/COLOR]',
            'action': 'regenerate_epg',
            'icon': 'DefaultAddonPVRClient.png',
            'description': 'Descargar guía de programación de iptv-epg.org'
        },
        {
            'label': '[COLOR cyan]⤓ Exportar M3U Playlist[/COLOR]',
            'action': 'export_m3u',
            'icon': 'DefaultPlaylist.png',
            'description': 'Exportar playlist para PVR IPTV Simple Client'
        },
        {
            'label': '[COLOR lime]⚙ Configurar PVR Simple Client[/COLOR]',
            'action': 'setup_pvr',
            'icon': 'DefaultAddonPVRClient.png',
            'description': 'Configurar PVR IPTV Simple Client automáticamente'
        },
        {
            'label': '[COLOR gray]☰ Ajustes del Addon[/COLOR]',
            'action': 'settings',
            'icon': 'DefaultAddonService.png',
            'description': 'Abrir configuración del addon'
        },
    ]
    
    for item in menu_items:
        li = xbmcgui.ListItem(label=item['label'])
        li.setArt({'icon': item['icon'], 'thumb': item['icon']})
        li.setInfo('video', {'title': item['label'], 'plot': item['description']})
        
        url = get_url(action=item['action'])
        is_folder = item['action'] == 'list_channels'
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=is_folder)
    
    xbmcplugin.endOfDirectory(_HANDLE)


def list_channels():
    """List all channels - simple flat list with icons"""
    xbmcplugin.setPluginCategory(_HANDLE, 'LiveTV - CZ/SK')
    xbmcplugin.setContent(_HANDLE, 'videos')
    
    channels = get_all_channels()
    
    # Sort alphabetically by name
    sorted_channels = sorted(channels.items(), key=lambda x: x[1].get('name', '').lower())
    
    for channel_id, channel_info in sorted_channels:
        name = channel_info.get('name', channel_id)
        logo_file = channel_info.get('logo', f'{channel_id}.png')
        logo_path = os.path.join(LOGO_PATH, logo_file)
        
        # Check if logo exists, use default otherwise
        if not os.path.exists(logo_path):
            logo_path = os.path.join(LOGO_PATH, 'default.png')
        
        li = xbmcgui.ListItem(label=name)
        li.setArt({
            'icon': logo_path,
            'thumb': logo_path,
            'poster': logo_path,
            'fanart': logo_path
        })
        li.setInfo('video', {
            'title': name,
            'mediatype': 'video'
        })
        li.setProperty('IsPlayable', 'true')
        
        url = get_url(action='play', channel=channel_id)
        xbmcplugin.addDirectoryItem(_HANDLE, url, li, isFolder=False)
    
    xbmcplugin.endOfDirectory(_HANDLE)


def play_channel(channel_id, mode=None, utc=None):
    """Play a channel"""
    channel_info = get_channel(channel_id)
    if not channel_info:
        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo('name'),
            'Channel not found',
            xbmcgui.NOTIFICATION_ERROR
        )
        return
    
    provider = channel_info.get('provider')
    stream_data = None
    
    # Handle catchup mode
    if mode == 'catchup' and utc:
        stream_data = get_catchup_stream(channel_id, provider, utc)
    else:
        # Live stream
        stream_data = get_live_stream(channel_id, provider, channel_info)
    
    if not stream_data:
        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo('name'),
            'Stream not available',
            xbmcgui.NOTIFICATION_ERROR
        )
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem())
        return
    
    if 'error' in stream_data:
        xbmcgui.Dialog().notification(
            ADDON.getAddonInfo('name'),
            stream_data['error'],
            xbmcgui.NOTIFICATION_WARNING
        )
        xbmcplugin.setResolvedUrl(_HANDLE, False, xbmcgui.ListItem())
        return
    
    # Create playable item
    li = xbmcgui.ListItem(path=stream_data['url'])
    
    # Set stream properties
    if stream_data.get('manifest_type') == 'hls':
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    
    # Set headers if provided
    if stream_data.get('headers'):
        header_str = '&'.join([f'{k}={quote_plus(v)}' for k, v in stream_data['headers'].items()])
        li.setProperty('inputstream.adaptive.stream_headers', header_str)
    
    # Set info
    if stream_data.get('title'):
        li.setInfo('video', {
            'title': stream_data.get('title'),
            'plot': stream_data.get('plot', '')
        })
    
    xbmcplugin.setResolvedUrl(_HANDLE, True, li)
    
    # Notification
    channel_name = channel_info.get('name', channel_id)
    xbmcgui.Dialog().notification(
        ADDON.getAddonInfo('name'),
        f'Playing: {channel_name}',
        xbmcgui.NOTIFICATION_INFO,
        2000
    )


def get_live_stream(channel_id, provider, channel_info):
    """Get live stream based on provider"""
    try:
        if provider == 'ct':
            return ct.get_live_stream(channel_id)
        elif provider == 'rtvs':
            # Map channel IDs for RTVS
            rtvs_map = {
                'jednotka': 'jednotka',
                'dvojka': 'dvojka',
                'stv24': '24',
                'rtvssport': 'sport',
                'rtvsonline': 'online',
                'rtvslive': 'rtvs',
                'nrsr': 'nrsr'
            }
            return rtvs.get_live_stream(rtvs_map.get(channel_id, channel_id))
        elif provider == 'prima':
            # Map channel IDs for Prima
            prima_map = {
                'prima': 'prima',
                'primacool': 'cool',
                'primamax': 'max',
                'primakrimi': 'krimi',
                'primalove': 'love',
                'primazoom': 'zoom',
                'primastar': 'star',
                'primashow': 'show',
                'cnnprimanews': 'cnn'
            }
            return prima.get_live_stream(prima_map.get(channel_id, channel_id))
        elif provider == 'nova':
            return nova.get_live_stream(channel_id)
        elif provider == 'joj':
            return joj.get_live_stream(channel_id)
        elif provider == 'ta3':
            return ta3.get_live_stream(channel_id)
        elif provider == 'ocko':
            return ocko.get_live_stream(channel_id)
        elif provider == 'simple':
            return simple.get_live_stream(channel_id)
        elif provider == 'markiza':
            # Markiza requires login
            email = ADDON.getSetting('markiza_email')
            password = ADDON.getSetting('markiza_password')
            if not email or not password:
                return {'error': 'Markiza: Set email/password in settings'}
            return markiza.get_live_stream(channel_id, email, password)
        elif provider == 'generic':
            return generic.get_live_stream(channel_id, channel_info.get('stream_url'))
        else:
            return None
    except Exception as e:
        xbmc.log(f'[LiveTV CZ/SK] Error getting stream: {e}', xbmc.LOGERROR)
        return None


def get_catchup_stream(channel_id, provider, utc_timestamp):
    """Get catchup stream based on provider"""
    try:
        if provider == 'ct':
            return ct.get_catchup_stream(channel_id, utc_timestamp)
        elif provider == 'rtvs':
            return rtvs.get_catchup_stream(channel_id, utc_timestamp)
        elif provider == 'prima':
            return prima.get_catchup_stream(channel_id, utc_timestamp)
        else:
            return {'error': 'Catchup not supported for this channel'}
    except Exception as e:
        xbmc.log(f'[LiveTV CZ/SK] Error getting catchup: {e}', xbmc.LOGERROR)
        return {'error': str(e)}


def export_m3u():
    """Export M3U playlist for use with PVR IPTV Simple Client"""
    # Create profile directory if needed
    if not os.path.exists(ADDON_PROFILE):
        os.makedirs(ADDON_PROFILE)
    
    m3u_path = os.path.join(ADDON_PROFILE, 'playlist.m3u')
    
    channels = get_all_channels()
    
    with open(m3u_path, 'w', encoding='utf-8') as f:
        f.write('#EXTM3U\n')
        f.write('# LiveTV - CZ/SK Playlist\n')
        f.write('# Generated by plugin.video.livetv.czsk\n\n')
        
        for channel_id, info in channels.items():
            name = info.get('name', channel_id)
            logo = info.get('logo', '')
            group = info.get('group', 'Other')
            
            # Use epg_id from iptv-epg.org (JEDNOTKA.cz, JOJ.cz, etc.)
            # EPG processor keeps original IDs, so M3U must use same IDs
            epg_id = info.get('epg_id', '')
            
            # Logo URL (use local path)
            logo_path = f"special://home/addons/plugin.video.livetv.czsk/resources/logos/{logo}"
            
            # Catchup tags
            catchup_tags = ''
            if info.get('catchup'):
                catchup_days = info.get('catchup_days', 7)
                catchup_source = f"plugin://plugin.video.livetv.czsk/?action=play&channel={channel_id}&mode=catchup&utc={{utc}}"
                catchup_tags = f' catchup="vod" catchup-source="{catchup_source}" catchup-days="{catchup_days}"'
            
            # Write channel entry - tvg-id uses iptv-epg.org ID (with .cz suffix)
            f.write(f'#EXTINF:-1 tvg-id="{epg_id}" tvg-name="{name}" tvg-logo="{logo_path}" group-title="{group}"{catchup_tags},{name}\n')
            f.write(f'plugin://plugin.video.livetv.czsk/?action=play&channel={channel_id}\n')
    
    xbmcgui.Dialog().ok(
        ADDON.getAddonInfo('name'),
        f'M3U playlist exported to:\n{m3u_path}'
    )


def setup_pvr():
    """Configure PVR IPTV Simple Client"""
    try:
        pvr = xbmcaddon.Addon('pvr.iptvsimple')
    except:
        xbmcgui.Dialog().ok(
            ADDON.getAddonInfo('name'),
            'PVR IPTV Simple Client not installed!\n'
            'Please install it from Kodi Add-ons > PVR Clients'
        )
        return
    
    # First export M3U
    if not os.path.exists(ADDON_PROFILE):
        os.makedirs(ADDON_PROFILE)
    
    m3u_path = os.path.join(ADDON_PROFILE, 'playlist.m3u')
    
    # Export playlist
    channels = get_all_channels()
    with open(m3u_path, 'w', encoding='utf-8') as f:
        f.write('#EXTM3U\n')
        for channel_id, info in channels.items():
            name = info.get('name', channel_id)
            logo = info.get('logo', '')
            group = info.get('group', 'Other')
            # Use epg_id from iptv-epg.org (with .cz suffix)
            epg_id = info.get('epg_id', '')
            logo_path = f"special://home/addons/plugin.video.livetv.czsk/resources/logos/{logo}"
            
            catchup_tags = ''
            if info.get('catchup'):
                catchup_days = info.get('catchup_days', 7)
                catchup_source = f"plugin://plugin.video.livetv.czsk/?action=play&channel={channel_id}&mode=catchup&utc={{utc}}"
                catchup_tags = f' catchup="vod" catchup-source="{catchup_source}" catchup-days="{catchup_days}"'
            
            f.write(f'#EXTINF:-1 tvg-id="{epg_id}" tvg-name="{name}" tvg-logo="{logo_path}" group-title="{group}"{catchup_tags},{name}\n')
            f.write(f'plugin://plugin.video.livetv.czsk/?action=play&channel={channel_id}\n')
    
    # Configure PVR
    if xbmcgui.Dialog().yesno(
        ADDON.getAddonInfo('name'),
        'Configure PVR IPTV Simple Client with LiveTV CZ/SK playlist?\n\n'
        'This will set the M3U path to the generated playlist.'
    ):
        pvr.setSetting('m3uPathType', '0')  # Local path
        pvr.setSetting('m3uPath', m3u_path)
        pvr.setSetting('startNum', '1')
        pvr.setSetting('logoPathType', '1')  # From M3U
        pvr.setSetting('logoFromEpg', '1')
        
        xbmcgui.Dialog().ok(
            ADDON.getAddonInfo('name'),
            'PVR IPTV Simple Client configured!\n\n'
            'Please restart Kodi for changes to take effect.'
        )


def open_settings():
    """Open addon settings"""
    ADDON.openSettings()


def regenerate_epg():
    """Manually regenerate EPG"""
    try:
        from epgprocessor import update_epg, get_epg_path
        
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON.getAddonInfo('name'), 'Downloading EPG from IPTV-EPG.ORG...')
        progress.update(10, 'Downloading EPG (this may take a while)...')
        
        result = update_epg()
        
        progress.update(100)
        progress.close()
        
        if result:
            epg_path = get_epg_path()
            file_size = os.path.getsize(epg_path) / (1024 * 1024)
            xbmcgui.Dialog().ok(
                ADDON.getAddonInfo('name'),
                f'EPG generated successfully!\n\n'
                f'File: {epg_path}\n'
                f'Size: {file_size:.2f} MB\n\n'
                f'Configure PVR IPTV Simple Client with this EPG file.'
            )
        else:
            xbmcgui.Dialog().ok(
                ADDON.getAddonInfo('name'),
                'EPG generation failed!\n\n'
                'Check Kodi log for details.'
            )
    except Exception as e:
        xbmc.log(f'[LiveTV CZ/SK] EPG error: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            ADDON.getAddonInfo('name'),
            f'EPG generation error:\n{str(e)}'
        )


def router(paramstring):
    """Route to appropriate function based on parameters"""
    params = dict(parse_qsl(paramstring))
    
    action = params.get('action')
    
    if not action:
        show_main_menu()
    elif action == 'list_channels':
        list_channels()
    elif action == 'play':
        play_channel(
            params.get('channel'),
            params.get('mode'),
            params.get('utc')
        )
    elif action == 'export_m3u':
        export_m3u()
    elif action == 'setup_pvr':
        setup_pvr()
    elif action == 'settings':
        open_settings()
    elif action == 'regenerate_epg':
        regenerate_epg()
    else:
        show_main_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
