# -*- coding: utf-8 -*-
"""
Channel definitions for LiveTV - CZ/SK
Only working channels included - Updated 2026-01-16
"""

CHANNELS = {
    # =====================================================
    # CZECH - CT (Ceska televize)
    # =====================================================
    'ct1': {
        'name': 'CT1',
        'provider': 'ct',
        'logo': 'ct1.png',
        'catchup': False
    },
    'ct2': {
        'name': 'CT2',
        'provider': 'ct',
        'logo': 'ct2.png',
        'catchup': False
    },
    'ct24': {
        'name': 'CT24',
        'provider': 'ct',
        'logo': 'ct24.png',
        'catchup': False
    },
    'ctsport': {
        'name': 'CT Sport',
        'provider': 'ct',
        'logo': 'ctsport.png',
        'catchup': False
    },
    'ctdart': {
        'name': 'CT:D/art',
        'provider': 'ct',
        'logo': 'ctdart.png',
        'catchup': False
    },
    
    # =====================================================
    # CZECH - Music channels (WORKING)
    # =====================================================
    'ocko': {
        'name': 'Ocko',
        'provider': 'generic',
        'logo': 'ocko.png',
        'stream_url': 'https://ocko-live-dash.ssl.cdn.cra.cz/cra_live2/ocko.stream.1.smil/playlist.m3u8',
        'catchup': False
    },
    'ockoexpres': {
        'name': 'Ocko Expres',
        'provider': 'generic',
        'logo': 'ockoexpress.png',
        'stream_url': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8',
        'catchup': False
    },
    'ockostar': {
        'name': 'Ocko Star',
        'provider': 'generic',
        'logo': 'ockostar.png',
        'stream_url': 'https://ocko-live.ssl.cdn.cra.cz/cra_live2/ocko_gold.stream.1.smil/playlist.m3u8',
        'catchup': False
    },
    'retromusic': {
        'name': 'Retro Music TV',
        'provider': 'generic',
        'logo': 'retro.png',
        'stream_url': 'https://stream.mediawork.cz/retrotv/retrotvHQ1/playlist.m3u8',
        'catchup': False
    },
    
    # =====================================================
    # SLOVAK - RTVS
    # =====================================================
    'jednotka': {
        'name': 'Jednotka',
        'provider': 'rtvs',
        'logo': 'jednotka.png',
        'catchup': False
    },
    'dvojka': {
        'name': 'Dvojka',
        'provider': 'rtvs',
        'logo': 'dvojka.png',
        'catchup': False
    },
    'rtvs24': {
        'name': ':24',
        'provider': 'rtvs',
        'logo': '24.png',
        'catchup': False
    },
    'rtvssport': {
        'name': 'RTVS Sport',
        'provider': 'rtvs',
        'logo': 'sport.png',
        'catchup': False
    },
    
    # =====================================================
    # SLOVAK - JOJ (WORKING!)
    # =====================================================
    'joj': {
        'name': 'JOJ',
        'provider': 'joj',
        'logo': 'joj.png',
        'catchup': False
    },
    'jojplus': {
        'name': 'JOJ Plus',
        'provider': 'joj',
        'logo': 'plus.png',
        'catchup': False
    },
    'wau': {
        'name': 'WAU',
        'provider': 'joj',
        'logo': 'wau.png',
        'catchup': False
    },
    'jojfamily': {
        'name': 'JOJ Family',
        'provider': 'joj',
        'logo': 'family.png',
        'catchup': False
    },
    'joj24': {
        'name': 'JOJ 24',
        'provider': 'joj',
        'logo': 'joj24.png',
        'catchup': False
    },
    'jojcinema': {
        'name': 'JOJ Cinema',
        'provider': 'joj',
        'logo': 'jojcinema.png',
        'catchup': False
    },
    'jojsport': {
        'name': 'JOJ Sport',
        'provider': 'joj',
        'logo': 'jojsport.png',
        'catchup': False
    },
    
    # CS channels (JOJ group - WORKING!)
    'csfilm': {
        'name': 'CS Film',
        'provider': 'joj',
        'logo': 'csfilm.png',
        'catchup': False
    },
    'cshistory': {
        'name': 'CS History',
        'provider': 'joj',
        'logo': 'cshistory.png',
        'catchup': False
    },
    'csmystery': {
        'name': 'CS Mystery',
        'provider': 'joj',
        'logo': 'csmystery.png',
        'catchup': False
    },
    
    # =====================================================
    # SLOVAK - TA3
    # =====================================================
    'ta3': {
        'name': 'TA3',
        'provider': 'ta3',
        'logo': 'ta3.png',
        'catchup': False
    },
}


def get_all_channels():
    """Get all channels"""
    return CHANNELS


def get_channels_by_country(country):
    """Not used in simple list"""
    return CHANNELS


def get_channel(channel_id):
    """Get single channel by ID"""
    return CHANNELS.get(channel_id)
