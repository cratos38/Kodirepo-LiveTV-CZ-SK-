# -*- coding: utf-8 -*-
"""
Provider: Prima (Czech TV)
Prima channels - limited availability
"""

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}


def get_live_stream(channel_id):
    """Prima requires geo/subscription - not available"""
    return {'error': 'Prima not available (geo-restricted)'}


def get_catchup_stream(channel_id, utc_timestamp):
    """Catchup not available"""
    return {'error': 'Catch-up not available'}
