# -*- coding: utf-8 -*-
"""
Provider: Prima (Czech TV)
Using iptv-org streams where available
"""

# Stream URLs - Prima requires login for most channels
# Only CNN Prima News might be available
STREAMS = {
    'prima': None,  # Requires subscription
    'primacool': None,
    'primamax': None,
    'primakrimi': None,
    'primalove': None,
    'primazoom': None,
    'primastar': None,
    'primashow': None,
    'cnnprima': None  # Sometimes available, geo-restricted
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}


def get_live_stream(channel_id):
    """Get live stream URL for Prima channel"""
    stream_url = STREAMS.get(channel_id)
    if stream_url:
        return {
            'url': stream_url,
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    return {'error': 'Prima requires subscription - stream not available'}


def get_catchup_stream(channel_id, utc_timestamp):
    """Catchup not available"""
    return {'error': 'Prima catch-up requires subscription'}


def get_epg(channel_id, date=None):
    """EPG not implemented yet"""
    return []
