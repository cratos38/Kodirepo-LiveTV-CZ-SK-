# -*- coding: utf-8 -*-
"""
Provider: TA3 (Slovak news channel)
"""

# TA3 stream - trying multiple sources
STREAMS = {
    'ta3': 'https://stream.ta3.com/live/ta3-720.m3u8'
}

# Alternative streams
STREAMS_ALT = {
    'ta3': 'http://88.212.15.19/live/ta3/playlist.m3u8'
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
}


def get_live_stream(channel_id):
    """Get live stream URL for TA3"""
    import requests
    
    # Try primary
    stream_url = STREAMS.get(channel_id)
    if stream_url:
        try:
            response = requests.head(stream_url, timeout=5, headers=HEADERS)
            if response.status_code == 200:
                return {
                    'url': stream_url,
                    'manifest_type': 'hls',
                    'headers': HEADERS
                }
        except:
            pass
    
    # Try alternative
    alt_url = STREAMS_ALT.get(channel_id)
    if alt_url:
        return {
            'url': alt_url,
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    
    return None
