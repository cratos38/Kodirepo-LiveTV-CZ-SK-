# -*- coding: utf-8 -*-
"""
Provider: CT (Ceska televize)
Using iptv-org streams
"""

# Stream URLs from iptv-org (publicly available)
STREAMS = {
    'ct1': 'https://flexi-s1.purplecdn.xyz/CT1_HD/tracks-v1a1/mono.ts.m3u8',
    'ct2': 'https://flexi-s1.purplecdn.xyz/CT2_HD/tracks-v1a1/mono.ts.m3u8',
    'ct24': 'https://dash2.antik.sk/live/ct24_avc_25p/playlist.m3u8',
    'ctsport': 'https://flexi-s1.purplecdn.xyz/CT_SPORT_HD/tracks-v1a1/mono.ts.m3u8',
    'ctdart': 'https://flexi-s1.purplecdn.xyz/CT_D_HD/tracks-v1a1/mono.ts.m3u8'
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}


def get_live_stream(channel_id):
    """Get live stream URL for CT channel"""
    stream_url = STREAMS.get(channel_id)
    if stream_url:
        return {
            'url': stream_url,
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    return None


def get_catchup_stream(channel_id, utc_timestamp):
    """Catchup not available for CT via public streams"""
    return {'error': 'Catch-up not available'}


def get_epg(channel_id, date=None):
    """EPG not implemented yet"""
    return []
