# -*- coding: utf-8 -*-
"""
Provider: Nova (Czech TV)
Nova channels require subscription - disabled
"""

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}


def get_live_stream(channel_id):
    """Nova requires subscription - not available"""
    return {'error': 'Nova requires subscription'}
