# -*- coding: utf-8 -*-
"""
Provider: Nova (Czech commercial TV)
LIVE TV - Limited availability due to geo-restrictions
"""

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': '*/*',
    'Referer': 'https://tv.nova.cz/'
}

# Nova channels - many have geo-restrictions
# Using known working streams from iptv-org
CHANNEL_STREAMS = {
    'nova': {
        'name': 'Nova',
        'stream_url': None,  # Geo-blocked
        'web_url': 'https://tv.nova.cz/'
    },
    'novacinema': {
        'name': 'Nova Cinema',
        'stream_url': None,  # Geo-blocked in most cases
        'web_url': 'https://tv.nova.cz/'
    },
    'novasport1': {
        'name': 'Nova Sport 1',
        'stream_url': None,  # Subscription required
        'web_url': 'https://tv.nova.cz/'
    },
    'novasport2': {
        'name': 'Nova Sport 2',
        'stream_url': None,  # Subscription required
        'web_url': 'https://tv.nova.cz/'
    }
}


def get_live_stream(channel_id):
    """
    Get live stream URL for Nova channel
    
    Nova has strict geo-restrictions and most streams require subscription.
    Free streams are very limited.
    
    Args:
        channel_id: Channel identifier
        
    Returns:
        dict with 'url' and 'manifest_type' or None
    """
    import requests
    
    channel_data = CHANNEL_STREAMS.get(channel_id)
    if not channel_data:
        return None
    
    # If we have a direct stream URL
    if channel_data.get('stream_url'):
        try:
            session = requests.Session()
            session.headers.update(HEADERS)
            response = session.head(channel_data['stream_url'], timeout=5, allow_redirects=True)
            if response.status_code == 200:
                return {
                    'url': channel_data['stream_url'],
                    'manifest_type': 'hls',
                    'headers': HEADERS
                }
        except:
            pass
    
    # Try to extract from web (rarely works for Nova)
    return _try_extract_stream(channel_id, channel_data)


def _try_extract_stream(channel_id, channel_data):
    """
    Try to extract Nova stream from web
    Usually fails due to geo-restrictions and DRM
    """
    import requests
    import re
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        response = session.get(channel_data['web_url'], timeout=15)
        
        # Look for any m3u8 URLs
        m3u8_pattern = r'(https?://[^\s"\']+\.m3u8[^\s"\']*)'
        matches = re.findall(m3u8_pattern, response.text)
        
        for match in matches:
            if 'nova' in match.lower():
                try:
                    test = session.head(match, timeout=5)
                    if test.status_code == 200:
                        return {
                            'url': match,
                            'manifest_type': 'hls',
                            'headers': HEADERS
                        }
                except:
                    continue
                    
    except Exception as e:
        print(f"[Nova Provider] Error: {e}")
    
    return {'error': 'Nova streams are geo-restricted or require subscription'}


def get_catchup_stream(channel_id, utc_timestamp):
    """
    Nova catchup - not available for free
    """
    return {'error': 'Nova catchup requires subscription'}
