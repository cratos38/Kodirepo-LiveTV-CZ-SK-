# -*- coding: utf-8 -*-
"""
Provider: RTVS (Slovak public TV)
LIVE TV using official RTVS streams
"""

# Direct stream URLs from RTVS/iptv-org
STREAMS = {
    'jednotka': 'https://n5.stv.livebox.sk/stv-tv/addfd31846e34200883cc2b4e9e6c855/stv1.smil/playlist.m3u8',
    'dvojka': 'https://n5.stv.livebox.sk/stv-tv/addfd31846e34200883cc2b4e9e6c855/stv2.smil/playlist.m3u8',
    'rtvs24': 'http://88.212.15.27/live/test_trojka_25p/playlist.m3u8',
    'rtvssport': 'http://88.212.15.27/live/test_rtvs_sport_hevc/playlist.m3u8'
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
}


def get_live_stream(channel_id):
    """Get live stream URL for RTVS channel"""
    stream_url = STREAMS.get(channel_id)
    if stream_url:
        return {
            'url': stream_url,
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    return None


def get_catchup_stream(channel_id, utc_timestamp):
    """Catchup - RTVS archive limited"""
    return {'error': 'Catch-up limited to own productions'}


def get_epg(channel_id, date=None):
    """EPG not implemented yet"""
    return []
