# -*- coding: utf-8 -*-
# Based on cache-sk's freeview.sk markiza provider
# License: AGPL v.3
# NOTE: Markiza requires login with email/password

import requests
import re

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

CHANNELS = {
    'markiza': "https://www.markiza.sk/live/1-markiza",
    'doma': "https://www.markiza.sk/live/3-doma",
    'dajto': "https://www.markiza.sk/live/2-dajto",
    'markizakrimi': "https://www.markiza.sk/live/22-krimi",
    'klasik': "https://www.markiza.sk/live/44-klasik"
}

MATCHER = {
    'default': r',"source":{"sources":\[{"src":"([^"]+)","type":"application/x-mpegurl"}\],'
}

BASE = "https://www.markiza.sk/prihlasenie"
ORIGIN = "https://media.cms.markiza.sk/"
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'
}


def get_live_stream(channel_id, email=None, password=None):
    """
    Get live stream URL for Markiza channels.
    Requires email and password for login.
    """
    if channel_id not in CHANNELS:
        return None
    
    if not email or not password:
        return {'error': 'Markiza requires login. Set email and password in settings.'}
    
    try:
        session = requests.Session()
        session.verify = False
        headers = {}
        headers.update(HEADERS)
        
        # Get login page
        response = session.get(BASE, headers=headers, timeout=15)
        content = response.text
        
        # Find login form token
        matches = re.search(r'<input type="hidden" name="_do" value="(.+)-loginForm-(.+)">', content)
        if not matches:
            return {'error': 'Could not find login form'}
        
        _do = matches.group(1) + '-loginForm-' + matches.group(2)
        
        # Login
        headers.update({'Referer': BASE})
        params = {'email': email, 'password': password, '_do': _do}
        response = session.post(BASE, data=params, headers=headers, allow_redirects=False, timeout=15)
        
        if response.status_code == 401:
            return {'error': 'Invalid login credentials'}
        
        if response.status_code != 302:
            return {'error': 'Login failed'}
        
        # Get channel page
        response = session.get(CHANNELS[channel_id], headers=headers, timeout=15)
        content = response.text
        
        # Find iframe
        matches = re.search(r'<iframe.*?data-src="([^"]+)".*?allowfullscreen.*</iframe>', content, re.DOTALL)
        if not matches:
            return {'error': 'Could not find video iframe'}
        
        iframe = matches.group(1)
        headers.update({'Referer': CHANNELS[channel_id]})
        
        # Get iframe content
        response = session.get(iframe, headers=headers, timeout=15)
        content = response.text
        
        # Find stream URL
        final_matcher = MATCHER.get(channel_id, MATCHER['default'])
        matches = re.search(final_matcher, content)
        if not matches:
            return {'error': 'Could not find stream URL'}
        
        hls = matches.group(1)
        headers.update({'Referer': ORIGIN, 'Origin': ORIGIN})
        
        return {
            'url': hls,
            'manifest_type': 'hls',
            'headers': headers
        }
        
    except Exception as e:
        return {'error': str(e)}
