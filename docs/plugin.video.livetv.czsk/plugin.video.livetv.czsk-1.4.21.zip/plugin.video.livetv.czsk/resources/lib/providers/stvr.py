# -*- coding: utf-8 -*-
# STVR (Slovenská televízia a rozhlas) provider
# Supports Live TV and Catchup from archive
# License: AGPL v.3

import requests
import re
import json
import os
import time

try:
    from urllib.parse import urlencode, quote
except ImportError:
    from urllib import urlencode, quote

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_DATA = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

# Channel IDs for live TV
CHANNELS = {
    'jednotka': 1,
    'dvojka': 2,
    'trojka': 3,
    '24': 3,
    'stv24': 3,
    'stvr24': 3,
    'sport': 15,
    'stvrsport': 15,
    'online': 4,
    'nrsr': 5,
    'stvr': 6
}

# Alternative streams (backup)
ALTERNATIVE = {
    'jednotka': 'https://ocko-live.ssl.cdn.cra.cz/channels/stv1/playlist/cze/live_hd.m3u8',
    'dvojka': 'https://ocko-live.ssl.cdn.cra.cz/channels/stv2/playlist/cze/live_hd.m3u8'
}

# API endpoints
API_BASE = "https://www.stvr.sk"
API_LIVE = "https://www.stvr.sk/json/live5f.json"
API_ARCHIVE = "https://www.stvr.sk/json/archive5f.json"
ARCHIVE_LIST = "https://www.stvr.sk/televizia/archiv"

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/html, */*',
    'Accept-Language': 'sk,cs;q=0.9,en;q=0.8',
    'Referer': 'https://www.stvr.sk/'
}

# Cache for archive index
ARCHIVE_INDEX_FILE = os.path.join(ADDON_DATA, 'stvr_archive_index.json')
ARCHIVE_INDEX_MAX_AGE = 86400  # 24 hours


def log(msg):
    """Log message to Kodi log"""
    xbmc.log(f"[STVR] {msg}", xbmc.LOGINFO)


def get_archive_index():
    """
    Get or update the archive index.
    The index maps program titles to their serie_id and video_id.
    """
    # Check if cached index exists and is fresh
    if os.path.exists(ARCHIVE_INDEX_FILE):
        try:
            mtime = os.path.getmtime(ARCHIVE_INDEX_FILE)
            if time.time() - mtime < ARCHIVE_INDEX_MAX_AGE:
                with open(ARCHIVE_INDEX_FILE, 'r', encoding='utf-8') as f:
                    index = json.load(f)
                    log(f"Loaded archive index from cache ({len(index)} programs)")
                    return index
        except Exception as e:
            log(f"Error loading cached index: {e}")
    
    # Download fresh index
    log("Downloading fresh archive index...")
    return update_archive_index()


def update_archive_index():
    """
    Download and cache the complete archive index from STVR.
    Scrapes all letters A-Z and numbers.
    """
    archive_index = {}
    session = requests.Session()
    session.headers.update(HEADERS)
    
    letters = 'abcdefghijklmnopqrstuvwxyz9'
    
    for letter in letters:
        try:
            url = f"{ARCHIVE_LIST}?l={letter}"
            response = session.get(url, timeout=15)
            html = response.text
            
            # Pattern: href="/televizia/archiv/SERIE/VIDEO" ... title="Pozrieť v archíve TITULO"
            pattern = r'href="/televizia/archiv/(\d+)/(\d+)"[^>]*title="(?:Pozrieť v archíve )?([^"]+)"'
            matches = re.findall(pattern, html)
            
            for serie_id, video_id, title in matches:
                # Clean title
                title_clean = title.replace('Pozrieť v archíve ', '').strip()
                if title_clean and title_clean not in archive_index:
                    archive_index[title_clean] = {
                        'serie_id': serie_id,
                        'video_id': video_id
                    }
            
            log(f"Letter {letter}: found {len(matches)} entries")
            
        except Exception as e:
            log(f"Error fetching letter {letter}: {e}")
    
    # Save to cache
    try:
        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(ARCHIVE_INDEX_FILE, 'w', encoding='utf-8') as f:
            json.dump(archive_index, f, ensure_ascii=False, indent=2)
        log(f"Saved archive index ({len(archive_index)} programs)")
    except Exception as e:
        log(f"Error saving index: {e}")
    
    return archive_index


def normalize_title(title):
    """Normalize title for comparison"""
    if not title:
        return ""
    # Lowercase and strip whitespace
    normalized = title.lower().strip()
    # Remove common suffixes like Roman numerals
    normalized = re.sub(r'\s+[IVXLCDM]+\.?$', '', normalized)
    # Remove year in parentheses
    normalized = re.sub(r'\s*\(\d{4}\)\s*$', '', normalized)
    return normalized


def find_in_archive(title):
    """
    Find a program in the archive by title.
    Returns dict with serie_id, video_id, and original_title if found.
    """
    if not title:
        return None
    
    archive_index = get_archive_index()
    if not archive_index:
        log("Archive index is empty")
        return None
    
    # Normalize search title
    search_normalized = normalize_title(title)
    
    # First try exact match (case-insensitive)
    for archive_title, info in archive_index.items():
        if normalize_title(archive_title) == search_normalized:
            log(f"Exact match: '{title}' -> '{archive_title}'")
            return {
                'serie_id': info['serie_id'],
                'video_id': info['video_id'],
                'original_title': archive_title
            }
    
    # Try partial match (title contains or is contained)
    for archive_title, info in archive_index.items():
        archive_normalized = normalize_title(archive_title)
        if search_normalized in archive_normalized or archive_normalized in search_normalized:
            log(f"Partial match: '{title}' -> '{archive_title}'")
            return {
                'serie_id': info['serie_id'],
                'video_id': info['video_id'],
                'original_title': archive_title
            }
    
    log(f"Not found in archive: '{title}'")
    return None


def is_in_archive(title):
    """Check if a program title exists in the archive"""
    return find_in_archive(title) is not None


def get_live_stream(channel_id, use_alternative=False):
    """Get live stream URL for STVR channels"""
    if channel_id not in CHANNELS:
        log(f"Unknown channel: {channel_id}")
        return None
    
    # Try alternative first if requested
    if use_alternative and channel_id in ALTERNATIVE:
        return {
            'url': ALTERNATIVE[channel_id],
            'manifest_type': 'hls',
            'headers': HEADERS
        }
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        # Get stream
        params = {'c': CHANNELS[channel_id]}
        response = session.get(API_LIVE, params=params, timeout=15)
        data = response.json()
        
        if 'clip' in data and 'sources' in data['clip']:
            clip = data['clip']
            sources = clip['sources']
            hls = None
            mpd = None
            
            for src in sources:
                if src['type'] == "application/dash+xml":
                    mpd = src['src'].replace('\n', '')
                elif src['type'] == "application/x-mpegurl":
                    hls = src['src'].replace('\n', '')
            
            title = clip.get('titleorig', clip.get('title', ''))
            
            # Prefer HLS
            if hls:
                log(f"Live stream for {channel_id}: {title}")
                return {
                    'url': hls,
                    'manifest_type': 'hls',
                    'headers': HEADERS,
                    'title': title
                }
            elif mpd:
                return {
                    'url': mpd,
                    'manifest_type': 'mpd',
                    'headers': HEADERS,
                    'title': title
                }
        
        # Fallback to alternative
        if channel_id in ALTERNATIVE:
            return {
                'url': ALTERNATIVE[channel_id],
                'manifest_type': 'hls',
                'headers': HEADERS
            }
            
    except Exception as e:
        log(f"Error getting live stream: {e}")
        # Try alternative on error
        if channel_id in ALTERNATIVE:
            return {
                'url': ALTERNATIVE[channel_id],
                'manifest_type': 'hls',
                'headers': HEADERS
            }
        return {'error': str(e)}
    
    return None


def get_catchup_stream(channel_id, provider, utc=None, title=None):
    """
    Get catchup stream from STVR archive.
    
    Args:
        channel_id: Channel identifier (jednotka, dvojka, etc.)
        provider: Provider name (stvr)
        utc: Unix timestamp (not used for STVR - we search by name)
        title: Program title to search for
    
    Returns:
        dict with url, manifest_type, headers, title, plot
        or dict with 'error' key on failure
    """
    log(f"Catchup request: channel={channel_id}, title={title}, utc={utc}")
    
    if not title:
        return {'error': 'No title provided for catchup'}
    
    # Find program in archive
    archive_info = find_in_archive(title)
    
    if not archive_info:
        return {'error': f'Program "{title}" not found in STVR archive'}
    
    video_id = archive_info['video_id']
    log(f"Found in archive: video_id={video_id}")
    
    # Get stream from archive API
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        params = {'id': video_id}
        response = session.get(API_ARCHIVE, params=params, timeout=15)
        data = response.json()
        
        if 'clip' not in data:
            # Check if it's just IP response (no video data)
            if 'IP' in data and len(data) == 1:
                return {'error': f'Video {video_id} not available'}
            return {'error': 'Invalid response from archive API'}
        
        clip = data['clip']
        sources = clip.get('sources', [])
        
        if not sources:
            return {'error': 'No sources in archive response'}
        
        hls = None
        mpd = None
        
        for src in sources:
            if src['type'] == "application/dash+xml":
                mpd = src['src'].replace('\n', '')
            elif src['type'] == "application/x-mpegurl":
                hls = src['src'].replace('\n', '')
        
        video_title = clip.get('title', title)
        description = clip.get('description', '')
        duration = clip.get('length', '')
        
        # Prefer HLS
        if hls:
            log(f"Catchup stream found: {video_title}")
            return {
                'url': hls,
                'manifest_type': 'hls',
                'headers': HEADERS,
                'title': video_title,
                'plot': description
            }
        elif mpd:
            return {
                'url': mpd,
                'manifest_type': 'mpd',
                'headers': HEADERS,
                'title': video_title,
                'plot': description
            }
        
        return {'error': 'No playable stream found'}
        
    except Exception as e:
        log(f"Error getting catchup stream: {e}")
        return {'error': str(e)}


def get_archive_programs():
    """
    Get list of all programs available in archive.
    Useful for EPG processing to mark which programs have catchup.
    """
    return get_archive_index()


def refresh_archive_index():
    """Force refresh of the archive index"""
    # Delete cached file to force refresh
    if os.path.exists(ARCHIVE_INDEX_FILE):
        os.remove(ARCHIVE_INDEX_FILE)
    return update_archive_index()
