# -*- coding: utf-8 -*-
# EPG Processor para LiveTV CZ/SK usando IPTV-EPG.ORG
# Based on Freeview.sk EPG Processor
# Author: cratos38

import io
import os
import sys
import gzip
import requests
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcvfs
    import xbmcaddon
    KODI_MODE = True
except ImportError:
    KODI_MODE = False

# ==================== CONFIG ====================
EPG_URL = "https://iptv-epg.org/files/epg-cz.xml.gz"
ADDON_ID = "plugin.video.livetv.czsk"

# Mapeo: nuestro channel_id → ID de IPTV-EPG.ORG
# Basado en el mapeo de Freeview.sk
CHANNEL_MAPPING = {
    # RTVS
    "jednotka": "JEDNOTKA.cz",
    "dvojka": "DVOJKA.cz",
    "stv24": "STV24.cz",
    "rtvssport": "RTVSSPORT.cz",
    
    # JOJ
    "joj": "JOJ.cz",
    "jojplus": "JOJPLUS.cz",
    "jojwau": "WAU.cz",
    "jojfamily": "JOJFAMILY.cz",
    "jojko": "JOJKO.cz",
    "joj24": "JOJ24.cz",
    "jojcinema": "JOJCINEMA.cz",
    "jojsport": "JOJŠPORT.cz",
    
    # CS Link
    "csfilm": "CSFILM.cz",
    "cshistory": "CSHISTORY.cz",
    "csmystery": "CSMYSTERY.cz",
    
    # TA3
    "ta3": "TA3.cz",
    
    # CT (Ceska televize)
    "ct1": "ČT1.cz",
    "ct2": "ČT2.cz",
    "ct24": "ČT24.cz",
    "ctsport": "ČTsport.cz",
    "ctdart": "ČT:D/ČTart.cz",
    
    # Nova
    "nova": "NOVA.cz",
    "novacinema": "NOVACINEMA.cz",
    "novaaction": "NOVAACTION.cz",
    "novafun": "NOVAFUN.cz",
    "novasport1": "NOVASPORT1.cz",
    "novasport2": "NOVASPORT2.cz",
    
    # Prima
    "prima": "PRIMA.cz",
    "primacool": "PRIMACOOL.cz",
    "primamax": "PRIMAMAX.cz",
    "primakrimi": "PRIMAKRIMI.cz",
    "primalove": "PRIMALOVE.cz",
    "primazoom": "PRIMAZOOM.cz",
    "primastar": "PRIMASTAR.cz",
    "primashow": "PRIMASHOW.cz",
    "cnnprimanews": "CNNPRIMANEWS.cz",
    
    # Ocko
    "ocko": "ÓČKO.cz",
    "ockoexpres": "ÓČKOEXPRES.cz",
    "ockostar": "ÓČKOSTAR.cz",
    
    # Markiza (si se añade)
    "markiza": "MARKIZA.cz",
    "markizakrimi": "MARKIZA_KRIMI.cz",
    "markizaklasik": "MarkizaKlasik.cz",
}

def log(message):
    """Log messages"""
    msg = "[LiveTV EPG] {}".format(message)
    if KODI_MODE:
        xbmc.log(msg, xbmc.LOGINFO)
    else:
        print(msg)

def get_addon_data_path():
    """Get addon data path"""
    if KODI_MODE:
        addon = xbmcaddon.Addon(ADDON_ID)
        userdata_path = xbmcvfs.translatePath('special://userdata')
        return os.path.join(userdata_path, 'addon_data', ADDON_ID)
    else:
        return os.path.join(os.path.dirname(__file__), '..', '..', 'userdata')

def download_epg():
    """Download EPG from IPTV-EPG.ORG"""
    log("Downloading EPG from: {}".format(EPG_URL))
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(EPG_URL, headers=headers, timeout=120)
        response.raise_for_status()
        
        # Decompress gzip
        xml_data = gzip.decompress(response.content)
        
        size_mb = len(xml_data) / (1024 * 1024)
        log("Downloaded and decompressed: {:.2f} MB".format(size_mb))
        
        return xml_data
        
    except Exception as e:
        log("ERROR downloading EPG: {}".format(str(e)))
        return None

def remap_channel_ids(xml_data):
    """Remap IDs in XMLTV to our channel IDs"""
    log("Remapping channel IDs...")
    
    try:
        # Parse XML
        root = ET.fromstring(xml_data)
        
        # Create reverse mapping: IPTV-EPG ID → our channel ID
        epg_to_our = {v: k for k, v in CHANNEL_MAPPING.items()}
        
        channels_mapped = 0
        programmes_mapped = 0
        channels_to_remove = []
        
        # Map <channel> elements
        for channel in root.findall('channel'):
            old_id = channel.get('id')
            
            if old_id in epg_to_our:
                new_id = epg_to_our[old_id]
                channel.set('id', new_id)
                channels_mapped += 1
                
                display_name = channel.find('display-name')
                ch_name = display_name.text if display_name is not None else old_id
                log("  Mapped: {} ({}) -> {}".format(ch_name, old_id, new_id))
            else:
                channels_to_remove.append(channel)
        
        # Remove unmapped channels
        for channel in channels_to_remove:
            root.remove(channel)
        
        # Map <programme> elements
        programmes = root.findall('programme')
        programmes_to_remove = []
        
        for programme in programmes:
            old_channel = programme.get('channel')
            
            if old_channel in epg_to_our:
                new_channel = epg_to_our[old_channel]
                programme.set('channel', new_channel)
                programmes_mapped += 1
            else:
                programmes_to_remove.append(programme)
        
        # Remove unmapped programmes
        for programme in programmes_to_remove:
            root.remove(programme)
        
        log("Channels mapped: {}".format(channels_mapped))
        log("Channels removed: {}".format(len(channels_to_remove)))
        log("Programmes mapped: {}".format(programmes_mapped))
        log("Programmes removed: {}".format(len(programmes_to_remove)))
        
        # Convert back to XML string
        xml_str = ET.tostring(root, encoding='utf-8', xml_declaration=True)
        
        return xml_str
        
    except Exception as e:
        log("ERROR remapping: {}".format(str(e)))
        import traceback
        log(traceback.format_exc())
        return None

def update_epg():
    """Main function to update EPG"""
    log("=" * 50)
    log("Starting EPG update from IPTV-EPG.ORG")
    log("=" * 50)
    
    # Download EPG
    xml_data = download_epg()
    if not xml_data:
        log("Failed to download EPG")
        return None
    
    # Remap channel IDs
    remapped_xml = remap_channel_ids(xml_data)
    if not remapped_xml:
        log("Failed to remap channel IDs")
        return None
    
    # Get addon data path
    addon_data_path = get_addon_data_path()
    log("Target directory: {}".format(addon_data_path))
    
    # Create directory if not exists
    if not os.path.exists(addon_data_path):
        try:
            os.makedirs(addon_data_path)
            log("Created directory: {}".format(addon_data_path))
        except Exception as e:
            log("ERROR creating directory: {}".format(str(e)))
            return None
    
    # EPG file path
    epg_path = os.path.join(addon_data_path, 'epg.xml')
    
    try:
        # Remove old file if exists
        if os.path.exists(epg_path):
            try:
                os.remove(epg_path)
                log("Removed old epg.xml")
            except:
                pass
        
        # Write EPG file
        with io.open(epg_path, 'wb') as f:
            f.write(remapped_xml)
        
        # Verify file was written
        if os.path.exists(epg_path):
            size_mb = os.path.getsize(epg_path) / (1024 * 1024)
            log("=" * 50)
            log("SUCCESS! EPG saved: {}".format(epg_path))
            log("File size: {:.2f} MB".format(size_mb))
            log("=" * 50)
            return epg_path
        else:
            log("ERROR: File was not created!")
            return None
        
    except Exception as e:
        log("ERROR saving EPG: {}".format(str(e)))
        import traceback
        log(traceback.format_exc())
        return None

def get_epg_path():
    """Get path to EPG file"""
    addon_data_path = get_addon_data_path()
    return os.path.join(addon_data_path, 'epg.xml')

def epg_exists():
    """Check if EPG file exists"""
    return os.path.exists(get_epg_path())

def get_epg_age_hours():
    """Get age of EPG file in hours"""
    epg_path = get_epg_path()
    if not os.path.exists(epg_path):
        return float('inf')
    
    import time
    file_time = os.path.getmtime(epg_path)
    age_seconds = time.time() - file_time
    return age_seconds / 3600

# Compatibility functions for Freeview-style API
def get_epg(channels, from_date, days=7, recalculate=True):
    """Freeview-compatible EPG function"""
    return update_epg()

def generate_xmltv(channels, epg, path):
    """Not used - IPTV-EPG.ORG already provides XMLTV"""
    pass

def generate_plot(epg, now, chtitle, items_left=3):
    """Not used in this mode"""
    return ""

def tidy_epg(epg_info):
    """Not used in this mode"""
    return epg_info

# Test standalone
if __name__ == '__main__':
    print("=" * 60)
    print("EPG PROCESSOR - LiveTV CZ/SK")
    print("Source: IPTV-EPG.ORG")
    print("=" * 60)
    
    result = update_epg()
    
    if result:
        print("\n" + "=" * 60)
        print("SUCCESS!")
        print("EPG file: {}".format(result))
        print("=" * 60)
        print("\nFor Kodi:")
        print("1. Install addon")
        print("2. Go to Settings -> Regenerate EPG")
        print("3. Configure PVR IPTV Simple Client:")
        print("   - M3U: Export from addon settings")
        print("   - EPG: " + result)
    else:
        print("\n" + "=" * 60)
        print("FAILED!")
        print("=" * 60)
