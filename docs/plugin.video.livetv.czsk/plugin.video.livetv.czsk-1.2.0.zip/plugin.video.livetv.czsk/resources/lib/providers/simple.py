# -*- coding: utf-8 -*-
# Based on cache-sk's freeview.sk simple provider
# License: AGPL v.3

CHANNELS = {
    'fashion': 'http://lb.streaming.sk/fashiontv/stream/playlist.m3u8',
    'doktor': 'https://live.tvdoktor.sk/high/index.m3u8',
    'szts': 'https://dash2.antik.sk/live/tanecnesutaze/index.m3u8'
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
    'referer': 'http://live.streaming.sk/'
}


def get_live_stream(channel_id):
    """Get live stream URL for simple channels"""
    if channel_id not in CHANNELS:
        return None
    
    return {
        'url': CHANNELS[channel_id],
        'manifest_type': 'hls',
        'headers': HEADERS
    }
