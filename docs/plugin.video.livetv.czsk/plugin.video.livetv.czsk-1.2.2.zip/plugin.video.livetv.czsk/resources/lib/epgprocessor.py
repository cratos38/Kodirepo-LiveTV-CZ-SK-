# -*- coding: utf-8 -*-
# EPG Processor para LiveTV CZ/SK usando IPTV-EPG.ORG
# Based on Freeview.sk EPG Processor
# Author: cratos38
#
# IMPORTANTE: NO remapeamos IDs!
# M3U usa: tvg-id="JEDNOTKA.cz" (igual que iptv-epg.org)
# EPG usa: channel="JEDNOTKA.cz" (sin cambiar)
# ¡ASÍ COINCIDEN!

import io
import os
import sys
import gzip
import requests
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcvfs
    import xbmcaddon
    KODI_MODE = True
except ImportError:
    KODI_MODE = False

# ==================== CONFIG ====================
EPG_URL = "https://iptv-epg.org/files/epg-cz.xml.gz"
ADDON_ID = "plugin.video.livetv.czsk"

# Lista de IDs de iptv-epg.org que nos interesan
# (los mismos que usamos en channels.py como epg_id)
WANTED_CHANNELS = [
    # RTVS (Slovak - pero iptv-epg.org usa .cz para todo!)
    "JEDNOTKA.cz",
    "DVOJKA.cz",
    "STV24.cz",
    "RTVSSPORT.cz",
    
    # JOJ (Slovak)
    "JOJ.cz",
    "JOJPLUS.cz",
    "WAU.cz",
    "JOJFAMILY.cz",
    "JOJKO.cz",
    "JOJ24.cz",
    "JOJCINEMA.cz",
    "JOJŠPORT.cz",
    
    # CS Link
    "CSFILM.cz",
    "CSFILM,MINI.cz",
    "CSHISTORY.cz",
    "CSHistory.cz",
    "CSMYSTERY.cz",
    "CSMystery.cz",
    
    # TA3
    "TA3.cz",
    
    # CT (Ceska televize)
    "ČT1.cz",
    "ČT2.cz",
    "ČT24.cz",
    "ČTsport.cz",
    "ČT:D/ČTart.cz",
    
    # Nova
    "NOVA.cz",
    "NOVACINEMA.cz",
    "NOVAACTION.cz",
    "NOVAFUN.cz",
    "NOVASPORT1.cz",
    "NOVASPORT2.cz",
    
    # Prima
    "PRIMA.cz",
    "PRIMACOOL.cz",
    "PRIMAMAX.cz",
    "PRIMAKRIMI.cz",
    "PRIMALOVE.cz",
    "PRIMAZOOM.cz",
    "PRIMASTAR.cz",
    "PRIMASHOW.cz",
    "CNNPRIMANEWS.cz",
    
    # Ocko
    "ÓČKO.cz",
    "ÓČKOEXPRES.cz",
    "ÓČKOSTAR.cz",
    
    # Markiza (por si se añade)
    "MARKIZA.cz",
    "MARKIZA_KRIMI.cz",
    "MarkizaKlasik.cz",
]

def log(message):
    """Log messages"""
    msg = "[LiveTV EPG] {}".format(message)
    if KODI_MODE:
        xbmc.log(msg, xbmc.LOGINFO)
    else:
        print(msg)

def get_addon_data_path():
    """Get addon data path"""
    if KODI_MODE:
        addon = xbmcaddon.Addon(ADDON_ID)
        userdata_path = xbmcvfs.translatePath('special://userdata')
        return os.path.join(userdata_path, 'addon_data', ADDON_ID)
    else:
        return os.path.join(os.path.dirname(__file__), '..', '..', 'userdata')

def download_epg():
    """Download EPG from IPTV-EPG.ORG"""
    log("Downloading EPG from: {}".format(EPG_URL))
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(EPG_URL, headers=headers, timeout=120)
        response.raise_for_status()
        
        # Decompress gzip
        xml_data = gzip.decompress(response.content)
        
        size_mb = len(xml_data) / (1024 * 1024)
        log("Downloaded and decompressed: {:.2f} MB".format(size_mb))
        
        return xml_data
        
    except Exception as e:
        log("ERROR downloading EPG: {}".format(str(e)))
        return None

def filter_channels(xml_data):
    """Filter EPG to only include our channels - NO REMAPPING!"""
    log("Filtering channels (keeping original IDs)...")
    
    try:
        # Parse XML
        root = ET.fromstring(xml_data)
        
        # Convert to set for faster lookup
        wanted_set = set(WANTED_CHANNELS)
        
        channels_kept = 0
        channels_removed = 0
        programmes_kept = 0
        programmes_removed = 0
        
        # Filter <channel> elements - keep only wanted ones
        channels_to_remove = []
        for channel in root.findall('channel'):
            channel_id = channel.get('id')
            
            if channel_id in wanted_set:
                channels_kept += 1
                display_name = channel.find('display-name')
                ch_name = display_name.text if display_name is not None else channel_id
                log("  Keeping: {} ({})".format(ch_name, channel_id))
            else:
                channels_to_remove.append(channel)
                channels_removed += 1
        
        # Remove unwanted channels
        for channel in channels_to_remove:
            root.remove(channel)
        
        # Filter <programme> elements - keep only for wanted channels
        programmes_to_remove = []
        for programme in root.findall('programme'):
            channel_id = programme.get('channel')
            
            if channel_id in wanted_set:
                programmes_kept += 1
            else:
                programmes_to_remove.append(programme)
                programmes_removed += 1
        
        # Remove unwanted programmes
        for programme in programmes_to_remove:
            root.remove(programme)
        
        log("Channels kept: {}".format(channels_kept))
        log("Channels removed: {}".format(channels_removed))
        log("Programmes kept: {}".format(programmes_kept))
        log("Programmes removed: {}".format(programmes_removed))
        
        # Convert back to XML string
        xml_str = ET.tostring(root, encoding='utf-8', xml_declaration=True)
        
        return xml_str
        
    except Exception as e:
        log("ERROR filtering: {}".format(str(e)))
        import traceback
        log(traceback.format_exc())
        return None

def update_epg():
    """Main function to update EPG"""
    log("=" * 50)
    log("Starting EPG update from IPTV-EPG.ORG")
    log("NOTE: Keeping original IDs (no remapping)")
    log("=" * 50)
    
    # Download EPG
    xml_data = download_epg()
    if not xml_data:
        log("Failed to download EPG")
        return None
    
    # Filter channels (NO remapping - keep original IDs!)
    filtered_xml = filter_channels(xml_data)
    if not filtered_xml:
        log("Failed to filter channels")
        return None
    
    # Get addon data path
    addon_data_path = get_addon_data_path()
    log("Target directory: {}".format(addon_data_path))
    
    # Create directory if not exists
    if not os.path.exists(addon_data_path):
        try:
            os.makedirs(addon_data_path)
            log("Created directory: {}".format(addon_data_path))
        except Exception as e:
            log("ERROR creating directory: {}".format(str(e)))
            return None
    
    # EPG file path
    epg_path = os.path.join(addon_data_path, 'epg.xml')
    
    try:
        # Remove old file if exists
        if os.path.exists(epg_path):
            try:
                os.remove(epg_path)
                log("Removed old epg.xml")
            except:
                pass
        
        # Write EPG file
        with io.open(epg_path, 'wb') as f:
            f.write(filtered_xml)
        
        # Verify file was written
        if os.path.exists(epg_path):
            size_mb = os.path.getsize(epg_path) / (1024 * 1024)
            log("=" * 50)
            log("SUCCESS! EPG saved: {}".format(epg_path))
            log("File size: {:.2f} MB".format(size_mb))
            log("=" * 50)
            return epg_path
        else:
            log("ERROR: File was not created!")
            return None
        
    except Exception as e:
        log("ERROR saving EPG: {}".format(str(e)))
        import traceback
        log(traceback.format_exc())
        return None

def get_epg_path():
    """Get path to EPG file"""
    addon_data_path = get_addon_data_path()
    return os.path.join(addon_data_path, 'epg.xml')

def epg_exists():
    """Check if EPG file exists"""
    return os.path.exists(get_epg_path())

def get_epg_age_hours():
    """Get age of EPG file in hours"""
    epg_path = get_epg_path()
    if not os.path.exists(epg_path):
        return float('inf')
    
    import time
    file_time = os.path.getmtime(epg_path)
    age_seconds = time.time() - file_time
    return age_seconds / 3600

# Compatibility functions for Freeview-style API
def get_epg(channels, from_date, days=7, recalculate=True):
    """Freeview-compatible EPG function"""
    return update_epg()

def generate_xmltv(channels, epg, path):
    """Not used - IPTV-EPG.ORG already provides XMLTV"""
    pass

def generate_plot(epg, now, chtitle, items_left=3):
    """Not used in this mode"""
    return ""

def tidy_epg(epg_info):
    """Not used in this mode"""
    return epg_info

# Test standalone
if __name__ == '__main__':
    print("=" * 60)
    print("EPG PROCESSOR - LiveTV CZ/SK")
    print("Source: IPTV-EPG.ORG")
    print("Mode: FILTER ONLY (no ID remapping)")
    print("=" * 60)
    
    result = update_epg()
    
    if result:
        print("\n" + "=" * 60)
        print("SUCCESS!")
        print("EPG file: {}".format(result))
        print("=" * 60)
        print("\nIDs in EPG match iptv-epg.org IDs:")
        print("  JEDNOTKA.cz, JOJ.cz, ČT1.cz, PRIMA.cz, etc.")
        print("\nM3U must use same IDs in tvg-id attribute!")
    else:
        print("\n" + "=" * 60)
        print("FAILED!")
        print("=" * 60)
