# -*- coding: utf-8 -*-
"""
Channel definitions for LiveTV - CZ/SK
All channels in a simple flat list
"""

CHANNELS = {
    # ============ CESKA TELEVIZE (CT) ============
    'ct1': {
        'name': 'CT1',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ct1.png',
        'catchup': False
    },
    'ct2': {
        'name': 'CT2',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ct2.png',
        'catchup': False
    },
    'ct24': {
        'name': 'CT24',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ct24.png',
        'catchup': False
    },
    'ctsport': {
        'name': 'CT Sport',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ctsport.png',
        'catchup': False
    },
    'ctdart': {
        'name': 'CT:D/art',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ctdart.png',
        'catchup': False
    },
    'ctsportplus': {
        'name': 'CT Sport Plus',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ctsportplus.png',
        'catchup': False
    },
    
    # ============ NOVA ============
    'nova': {
        'name': 'Nova',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'nova.png',
        'catchup': False
    },
    'novacinema': {
        'name': 'Nova Cinema',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novacinema.png',
        'catchup': False
    },
    'novaaction': {
        'name': 'Nova Action',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novaaction.png',
        'catchup': False
    },
    'novafun': {
        'name': 'Nova Fun',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novafun.png',
        'catchup': False
    },
    'novalady': {
        'name': 'Nova Lady',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novalady.png',
        'catchup': False
    },
    'novagold': {
        'name': 'Nova Gold',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novagold.png',
        'catchup': False
    },
    'novasport1': {
        'name': 'Nova Sport 1',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novasport1.png',
        'catchup': False
    },
    'novasport2': {
        'name': 'Nova Sport 2',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novasport2.png',
        'catchup': False
    },
    
    # ============ PRIMA ============
    'prima': {
        'name': 'Prima',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'prima.png',
        'catchup': False
    },
    'primacool': {
        'name': 'Prima Cool',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primacool.png',
        'catchup': False
    },
    'primamax': {
        'name': 'Prima Max',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primamax.png',
        'catchup': False
    },
    'primakrimi': {
        'name': 'Prima Krimi',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primakrimi.png',
        'catchup': False
    },
    'primalove': {
        'name': 'Prima Love',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primalove.png',
        'catchup': False
    },
    'primazoom': {
        'name': 'Prima Zoom',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primazoom.png',
        'catchup': False
    },
    'primastar': {
        'name': 'Prima Star',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primastar.png',
        'catchup': False
    },
    'primashow': {
        'name': 'Prima Show',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primashow.png',
        'catchup': False
    },
    'cnnprimanews': {
        'name': 'CNN Prima News',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'cnnprimanews.png',
        'catchup': False
    },
    
    # ============ BARRANDOV ============
    'barrandov': {
        'name': 'TV Barrandov',
        'provider': 'generic',
        'country': 'CZ',
        'group': 'Barrandov',
        'logo': 'barrandov.png',
        'stream_url': 'https://stream-25.mazana.tv/barrandov.m3u8',
        'catchup': False
    },
    'barrandovkino': {
        'name': 'Kino Barrandov',
        'provider': 'generic',
        'country': 'CZ',
        'group': 'Barrandov',
        'logo': 'kinobarrandov.png',
        'stream_url': 'http://83.167.253.107/hdmi1_ext',
        'catchup': False
    },
    
    # ============ OCKO (Music) ============
    'ocko': {
        'name': 'Ocko',
        'provider': 'generic',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'ocko.png',
        'stream_url': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko/playlist.m3u8',
        'catchup': False
    },
    'ockoexpres': {
        'name': 'Ocko Expres',
        'provider': 'generic',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'ockoexpress.png',
        'stream_url': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8',
        'catchup': False
    },
    'ockostar': {
        'name': 'Ocko Star',
        'provider': 'generic',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'ockostar.png',
        'stream_url': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_gold/playlist.m3u8',
        'catchup': False
    },
    'retromusic': {
        'name': 'Retro Music TV',
        'provider': 'generic',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'retro.png',
        'stream_url': 'https://stream.mediawork.cz/retrotv/retrotvHQ1/playlist.m3u8',
        'catchup': False
    },
    
    # ============ CS LINK ============
    'csfilm': {
        'name': 'CS Film',
        'provider': 'joj',
        'country': 'CZ',
        'group': 'CS Link',
        'logo': 'csfilm.png',
        'catchup': False
    },
    'cshistory': {
        'name': 'CS History',
        'provider': 'joj',
        'country': 'CZ',
        'group': 'CS Link',
        'logo': 'cshistory.png',
        'catchup': False
    },
    'csmystery': {
        'name': 'CS Mystery',
        'provider': 'joj',
        'country': 'CZ',
        'group': 'CS Link',
        'logo': 'csmystery.png',
        'catchup': False
    },
    
    # ============ RTVS (Slovak) ============
    'jednotka': {
        'name': 'Jednotka',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': 'jednotka.png',
        'catchup': False
    },
    'dvojka': {
        'name': 'Dvojka',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': 'dvojka.png',
        'catchup': False
    },
    'stv24': {
        'name': 'RTVS :24',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': '24.png',
        'catchup': False
    },
    'rtvssport': {
        'name': 'RTVS Sport',
        'provider': 'rtvs',
        'country': 'SK',
        'group': 'RTVS',
        'logo': 'rtvssport.png',
        'catchup': False
    },
    
    # ============ JOJ (Slovak) ============
    'joj': {
        'name': 'JOJ',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'joj.png',
        'catchup': False
    },
    'jojplus': {
        'name': 'JOJ Plus',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojplus.png',
        'catchup': False
    },
    'jojwau': {
        'name': 'WAU',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'wau.png',
        'catchup': False
    },
    'jojfamily': {
        'name': 'JOJ Family',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojfamily.png',
        'catchup': False
    },
    'jojcinema': {
        'name': 'JOJ Cinema',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojcinema.png',
        'catchup': False
    },
    'joj24': {
        'name': 'JOJ 24',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'joj24.png',
        'catchup': False
    },
    'jojsport': {
        'name': 'JOJ Sport',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojsport.png',
        'catchup': False
    },
    'jojko': {
        'name': 'JOJko',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojko.png',
        'catchup': False
    },
    
    # ============ DAJTO ============
    'dajto': {
        'name': 'Dajto',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'dajto.png',
        'catchup': False
    },
    
    # ============ TA3 (Slovak News) ============
    'ta3': {
        'name': 'TA3',
        'provider': 'ta3',
        'country': 'SK',
        'group': 'News',
        'logo': 'ta3.png',
        'catchup': False
    },
}


def get_all_channels():
    """Return all channels sorted alphabetically"""
    return dict(sorted(CHANNELS.items(), key=lambda x: x[1]['name'].lower()))


def get_channel(channel_id):
    """Get channel info by ID"""
    return CHANNELS.get(channel_id)
